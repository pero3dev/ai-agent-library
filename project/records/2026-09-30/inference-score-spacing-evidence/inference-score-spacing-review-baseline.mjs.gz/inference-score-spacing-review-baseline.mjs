import {execFileSync} from 'node:child_process'
import {readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import path from 'node:path'
const sha=v=>createHash('sha256').update(v).digest('hex'),tmp=process.env.TEMP,T=f=>path.join(tmp,'inference-score-spacing-review-'+f),ref='ca3c09eebd1b549564f874f3304d23ae25328194',file='website/components/diagrams/inference-sampling.css',bytes=execFileSync('git',['show',ref+':'+file],{cwd:'C:/dev/ai-agent-library',windowsHide:true}),review=JSON.parse(await readFile(path.join(tmp,'pretraining-public-review.json'),'utf8'))
if(review.release.mergeSha!==ref)throw Error('Wrong prior review SHA')
await writeFile(T('pr61.css'),bytes);await writeFile(T('pr61-inputs.json'),JSON.stringify({articles:review.inputDigestsAtReview},null,2)+'\n')
const meta={checkedAt:new Date().toISOString(),ref,file,gitBlobSHA256:sha(bytes),sourceReviewSHA256:sha(await readFile(path.join(tmp,'pretraining-public-review.json'))),raceCorrection:'Initial before.css/before-inputs copy happened after root inserted candidate rule; retained unchanged and excluded from old baseline. Prior published Git blob and already-frozen PR61 input digests are the correct old baseline.',initialCopiedCSS_SHA256:sha(await readFile(T('before.css')))}
await writeFile(T('baseline-provenance.json'),JSON.stringify(meta,null,2)+'\n');console.log(JSON.stringify(meta,null,2))
