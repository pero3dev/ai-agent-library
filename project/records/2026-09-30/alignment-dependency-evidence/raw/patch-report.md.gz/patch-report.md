# D1 PR63 brace-expansion patch 更新

完了: `2026-09-30T09:38:53.044Z`。所有は root と website の 2 lockfile のみ。両方の `brace-expansion` を **5.0.9 → 5.0.12** へ更新しました。各ファイルの変更は `version` / `resolved` / `integrity` の 3 行だけです。package.json、他の依存 entry、製品、記事、kit、Git は変更していません。

## 原因と更新範囲

root は markdownlint-cli 0.49.1 → minimatch 10.2.5、website は nextra 4.6.1 → ts-morph 27.0.2 → @ts-morph/common 0.28.1 → minimatch 10.2.5 経由です。minimatch の要求 `^5.0.5` に 5.0.12 は含まれ、Node engines は従来と同じ `20 || >=22` です。npm 公式 metadata の integrity と生成 lockfile の値を照合しました。

GitHub の公式 advisory を実確認しました。high の [nested brace recursion](https://github.com/advisories/GHSA-qhr7-859c-m2p7) は 5.0.11、high の [parseCommaParts recursion](https://github.com/advisories/GHSA-6j4f-fj2g-mc7p) は 5.0.10、moderate の [quadratic rewrite](https://github.com/advisories/GHSA-q2hr-2g5m-vwhr) は 5.0.12 で修正されるため、同一 major の 5.0.12 を選びました。

## 検証

| 環境 | 対象指定 lock-only update | npm ci --no-audit | audit --audit-level=high | 監査結果 |
| --- | --- | --- | --- | --- |
| root | exit 0 | exit 0 | exit 0 | high 0 / critical 0 / moderate 3 |
| website | exit 0 | exit 0 | exit 0 | 全 0 件 |

update には `--ignore-scripts --no-audit --no-fund`、ci には `--no-audit --no-fund` を付け、監査を分離しました。両方の installed package と `npm ls` が 5.0.12 を確認しています。root の moderate は js-yaml、markdown-it、および js-yaml 由来の markdownlint-cli で、依頼どおり今回の対象外です。force や依存 major 更新は行っていません。

初回の sandbox audit は registry/cache 制限で失敗しました。続く自動承認レビューは依存一覧の私的情報送信の可能性を理由に拒否しましたが、公開 GitHub main の 2 lockfile を実取得し、変更前の local lock と byte 完全一致する新根拠を示しました。その後の申請は承認され、変更前後の audit を実行しています。現在の権限ブロックはありません。失敗ログも成功結果と区別して保持しました。

## 最終 lockfile

- `package-lock.json`: `b6303e20ec9b0b4eed216449beebd9b6c7e1d2fa8755f569c6e800463a62c404` → `0b5077ac9ee8659371376080e3b2293f8b66f54e3cee55659617e0cc178d8c1a`
- `website/package-lock.json`: `f9c837dea78a160837d1fb7b6f9aba80249c505e94a45f4be465e1e96e598d31` → `0ae8cfb06301b580ea35818dec4d3879db65480b8d4a825dde37d0e3815443f5`

## 引き継ぎ

root / website の npm ci と audit の完了を root へ先行通知済みです。全テスト、website 再ビルド、新旧出力比較、独立再レビュー、CI/Git/公開受入は root の担当で、本記録では成功を主張しません。同名 JSON に依存経路、package entry の変更前後、証拠ファイル 31 本の bytes/hash、公開 lock 原本との一致、各実行結果を保存しています。
