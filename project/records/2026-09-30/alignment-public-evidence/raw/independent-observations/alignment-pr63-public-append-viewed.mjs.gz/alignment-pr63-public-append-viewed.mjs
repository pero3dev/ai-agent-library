import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
const file=path.join(os.tmpdir(),'alignment-pr63-public-viewed-images-working.json'),entries=JSON.parse(fs.readFileSync(file,'utf8')),batch=JSON.parse(fs.readFileSync(process.argv[2],'utf8'))
for(const row of batch){assert.equal(row.actuallyViewed,true);assert.ok(!entries.some(v=>v.file.replaceAll('\\','/')===row.file.replaceAll('\\','/')));entries.push(row)}
fs.writeFileSync(file,JSON.stringify(entries,null,2)+'\n')
await import('./alignment-pr63-public-enrich-viewed.mjs')
