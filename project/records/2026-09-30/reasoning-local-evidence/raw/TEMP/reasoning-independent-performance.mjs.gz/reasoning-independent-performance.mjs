import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { gzipSync } from 'node:zlib'
import { TRACKED_ARTICLES, getDiagramArticleAcceptance } from '../website/lib/diagram-article-acceptance.mjs'

// D2 adaptation of alignment-independent-performance.mjs. Run only after its
// independent review and against the frozen, served static export.
const repo = 'C:/dev/ai-agent-library', base = 'http://127.0.0.1:4183/ai-agent-library'
const output = path.join(os.tmpdir(), 'reasoning-independent-performance', new Date().toISOString().replaceAll(':', '-'))
await fs.mkdir(output, { recursive: true })
const require = createRequire(path.join(repo, 'website/package.json'))
const { chromium, expect: originalExpect } = require('@playwright/test'), expect = originalExpect.configure({ timeout: 20000 })
const sha = bytes => createHash('sha256').update(bytes).digest('hex'), read = file => fs.readFile(path.join(repo, file))
const route = '/docs/llm-foundations/reasoning-models', targetIds = ['reasoning-sequence', 'reasoning-evaluation']
const report = {
  kind: 'independent-local-performance', startedAt: new Date().toISOString(),
  environment: { os: os.platform(), release: os.release(), arch: os.arch(), node: process.version, viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1, cpuNetworkThrottling: 'none', transport: 'loopback uncompressed static export' },
  thresholds: { commonGzipBytes: 100 * 1024, sceneGzipBytes: 75 * 1024, cls: .05, inputMs: 200, rafP95Ms: 32, idleSettleMs: 200, idleWindowMs: 500 },
  cold: [], performance: [], errors: [], networkErrors: []
}
const save = () => fs.writeFile(path.join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n')

async function identity() {
  const buildId = (await read('website/.next/BUILD_ID')).toString().trim(), articles = []
  for (const article of TRACKED_ARTICLES) {
    const articleRoute = '/docs/' + article.replace(/^docs\/\d+-/, '').replace(/\.md$/, '')
    const bytes = await read('website/out' + articleRoute + '.html'), response = await fetch(base + articleRoute), live = Buffer.from(await response.arrayBuffer())
    assert.equal(response.status, 200); assert.equal(sha(live), sha(bytes))
    const ids = [...new Set([...bytes.toString().replaceAll('\\"', '"').matchAll(/"b":"([A-Za-z0-9_-]+)"/g)].map(match => match[1]))]
    assert.deepEqual(ids, [buildId])
    articles.push({ article, route: articleRoute, inputDigest: getDiagramArticleAcceptance({ repoRoot: repo, article }).inputDigest, htmlSHA256: sha(bytes) })
  }
  assert.equal(articles.length, 10)
  return { buildId, articles }
}
report.before = await identity()
const browser = await chromium.launch({ channel: 'msedge', headless: true })
report.environment.browser = browser.version()
const markers = ['REASONING / SEQUENCE', 'REASONING / EVALUATION']
const unrelated = ['ALIGNMENT /', 'PRETRAINING /', 'TRAINING /', 'SELF-ATTENTION', 'TRANSFORMER /', 'ATTENTION /', 'ATTENTION VARIANTS /', 'MOE /', 'MoE /', 'GENERATION /', 'TOKENIZATION /', 'INFERENCE /']
const emitted = []
for (const file of await fs.readdir(path.join(repo, 'website/out/_next/static/chunks'))) {
  if (!file.endsWith('.js')) continue
  const bytes = await read('website/out/_next/static/chunks/' + file), text = bytes.toString()
  const found = markers.filter(marker => text.includes(marker)), foreign = unrelated.filter(marker => text.includes(marker))
  const sharedEntry = text.includes('図解を読み込めませんでした。本文は引き続き読めます。'), sharedReading = text.includes('INTERACTIVE READING')
  if (found.length || foreign.length || sharedEntry || sharedReading) emitted.push({ file, sha256: sha(bytes), bytes: bytes.length, gzip: gzipSync(bytes).length, markers: found, unrelated: foreign, sharedEntry, sharedReading })
}
report.emitted = emitted

async function open(page, targetRoute) {
  const response = await page.goto(base + targetRoute, { waitUntil: 'load' })
  assert.equal(response.status(), 200)
  await page.evaluate(() => document.fonts.ready)
  await page.waitForFunction(() => [...document.querySelectorAll('.reading-figure')].every(node => node.dataset.ready === 'true'), null, { polling: 50 })
}
function observeNetwork(page, label) {
  page.on('pageerror', error => report.networkErrors.push({ label, at: new Date().toISOString(), type: 'pageerror', message: String(error) }))
  page.on('console', message => { if (message.type() === 'error') report.networkErrors.push({ label, at: new Date().toISOString(), type: 'console', message: message.text() }) })
  page.on('requestfailed', request => report.networkErrors.push({ label, at: new Date().toISOString(), type: 'requestfailed', resourceType: request.resourceType(), url: request.url(), failure: request.failure() }))
}
function cls(entries) {
  let max = 0, total = 0, start = -Infinity, last = -Infinity, current = 0
  for (const entry of entries.filter(entry => !entry.input)) {
    total += entry.value
    if (entry.time - last > 1000 || entry.time - start > 5000) { start = entry.time; current = 0 }
    current += entry.value; last = entry.time; max = Math.max(max, current)
  }
  return { maximumSessionWindow: max, sum: total }
}

function installRafInstrumentation() {
  const nativeRequest = window.requestAnimationFrame.bind(window), nativeCancel = window.cancelAnimationFrame.bind(window)
  const pending = new Set()
  let requested = 0, executed = 0, canceled = 0
  window.requestAnimationFrame = callback => {
    if (typeof callback !== 'function') return nativeRequest(callback)
    const handle = nativeRequest(function (timestamp) {
      pending.delete(handle); executed++
      callback.call(this, timestamp)
    })
    requested++; pending.add(handle)
    return handle
  }
  window.cancelAnimationFrame = handle => {
    if (pending.delete(handle)) canceled++
    return nativeCancel(handle)
  }
  // Every measuring callback uses this saved native function, never the wrapper.
  Object.defineProperty(window, '__reasoningPerformance', { value: Object.freeze({
    nativeRequest,
    snapshot: () => ({ requested, executed, canceled, pending: pending.size, pendingHandles: [...pending] })
  }) })
}

try {
  for (const [label, target] of [['D2', route], ['negative-control', '/docs/implementation/embeddings']]) {
    const context = await browser.newContext({ viewport: report.environment.viewport, deviceScaleFactor: 1, reducedMotion: 'reduce' })
    await context.addInitScript(() => {
      window.__shifts = []; window.__scrollEvents = 0
      addEventListener('scroll', () => window.__scrollEvents++, { passive: true })
      new PerformanceObserver(list => {
        for (const entry of list.getEntries()) window.__shifts.push({ time: entry.startTime, value: entry.value, input: entry.hadRecentInput, figures: (entry.sources || []).map(source => source.node?.closest?.('.reading-figure')?.dataset.diagramId || null) })
      }).observe({ type: 'layout-shift', buffered: true })
    })
    const page = await context.newPage(), observed = []
    observeNetwork(page, label)
    page.on('response', response => { if (/\/_next\/static\/chunks\/[^/]+\.js/.test(response.url())) observed.push({ file: path.basename(new URL(response.url()).pathname), status: response.status(), url: response.url() }) })
    await open(page, target); await page.waitForTimeout(5000)
    const values = await page.evaluate(() => ({ shifts: window.__shifts, scrollY, scrollEvents: window.__scrollEvents, figures: document.querySelectorAll('.reading-figure').length }))
    assert.equal(values.scrollY, 0); assert.equal(values.scrollEvents, 0)
    const requested = emitted.filter(entry => observed.some(item => item.file === entry.file))
    const scene = requested.filter(entry => entry.markers.length || entry.sharedReading), shared = requested.filter(entry => entry.sharedEntry)
    const sceneGzip = scene.reduce((sum, entry) => sum + entry.gzip, 0), sharedGzip = shared.reduce((sum, entry) => sum + entry.gzip, 0)
    assert.ok(observed.every(item => item.status === 200)); assert.ok(sceneGzip <= 75 * 1024); assert.ok(sharedGzip <= 100 * 1024)
    const allCLS = cls(values.shifts), figureCLS = cls(values.shifts.filter(entry => entry.figures.some(Boolean)))
    assert.ok(allCLS.maximumSessionWindow <= .05); assert.ok(figureCLS.maximumSessionWindow <= .05)
    if (label === 'D2') {
      assert.equal(values.figures, 2); assert.deepEqual(requested.flatMap(entry => entry.markers).sort(), markers.slice().sort())
      assert.equal(requested.flatMap(entry => entry.unrelated).length, 0)
    } else {
      assert.equal(values.figures, 0); assert.equal(sceneGzip, 0); assert.equal(requested.flatMap(entry => entry.unrelated).length, 0)
    }
    report.cold.push({ label, route: target, ...values, allCLS, figureCLS, sceneGzip, sharedGzip, requested, observed, method: 'Fresh context. load and fonts ready, then 5 s without input or scrolling. CLS session gap <=1 s, window <=5 s. gzipSync default on whole emitted chunks; conservative module-size bound, not actual transfer size.' })
    await context.close(); await save()
  }

  const context = await browser.newContext({ viewport: report.environment.viewport, deviceScaleFactor: 1, reducedMotion: 'no-preference' })
  await context.addInitScript(installRafInstrumentation)
  const page = await context.newPage()
  observeNetwork(page, 'native-performance'); await open(page, route)
  const panelOf = id => page.locator(`.reading-figure[data-diagram-id="${id}"] .aw-sticky > .aw-diagram`)
  async function seek(panel, index) {
    const button = panel.getByRole('group', { name: '図解の段階', exact: true }).getByRole('button').nth(index)
    await button.evaluate(node => node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }))
    await expect.poll(() => button.evaluate(async node => {
      const sample = () => { const rect = node.getBoundingClientRect(); return JSON.stringify([scrollY, node.closest('.aw-diagram').dataset.stage, rect.x, rect.y, rect.width, rect.height]) }
      const rect = node.getBoundingClientRect()
      if (rect.top < 0 || rect.bottom > innerHeight) return false
      const before = sample()
      for (let index = 0; index < 3; index++) { await new Promise(resolve => window.__reasoningPerformance.nativeRequest(resolve)); if (sample() !== before) return false }
      return true
    })).toBe(true)
    await button.click(); await expect(panel).toHaveAttribute('data-stage', String(index)); await expect(panel).toHaveAttribute('data-mode', 'manual')
  }
  const snapshot = panel => panel.evaluate(node => {
    const rect = node.closest('.aw-sticky').getBoundingClientRect()
    return { at: performance.now(), counters: window.__reasoningPerformance.snapshot(), phase: node.querySelector('input[type=range]').value, mode: node.dataset.mode, scrollY, viewportHeight: innerHeight,
      panelBounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height, top: rect.top, bottom: rect.bottom }, outsideViewport: rect.bottom <= 0 || rect.top >= innerHeight }
  })
  async function idleProof(panel, label, outside = false) {
    await page.waitForTimeout(200)
    const before = await snapshot(panel)
    await page.waitForTimeout(500)
    const after = await snapshot(panel)
    const observation = { label, settleMs: 200, windowMs: after.at - before.at, before, after,
      requestedDelta: after.counters.requested - before.counters.requested,
      executedDelta: after.counters.executed - before.counters.executed }
    // Save raw observations before any assertion so a failed idle proof survives.
    ;(report.idleObservations ??= []).push(observation); await save()
    assert.ok(observation.windowMs >= 500)
    assert.equal(before.mode, 'manual'); assert.equal(after.mode, 'manual'); assert.equal(after.phase, before.phase)
    assert.equal(before.counters.pending, 0); assert.equal(after.counters.pending, 0)
    assert.equal(observation.requestedDelta, 0); assert.equal(observation.executedDelta, 0)
    if (outside) { assert.equal(before.outsideViewport, true); assert.equal(after.outsideViewport, true) }
    return observation
  }
  // Ordinary UI operations isolate measured playback from the other figure's
  // intentional 800 ms reading-scroll transition. No DOM/style is rewritten.
  for (const id of targetIds) await seek(panelOf(id), 0)
  report.nativeMethod = { initialManualFigures: targetIds, applicationRaf: 'Main-page requestAnimationFrame calls made after document-start instrumentation; canceled handles removed, callback entry counted.', observers: 'Saved native rAF is used for seek stability, first-response timing and interval sampling, excluded from application counters.', exclusions: 'No physical device, GPU frame-time claim, hidden-document simulation, worker/iframe/timer accounting or production performance telemetry.' }
  for (const id of targetIds) {
    const panel = panelOf(id)
    await seek(panel, 0)
    await panel.evaluate(node => {
      window.__responseMs = null
      node.addEventListener('click', () => {
        const begin = performance.now(), initial = node.querySelector('input[type=range]').value
        function tick() {
          if (node.querySelector('input[type=range]').value !== initial) window.__responseMs = performance.now() - begin
          else if (performance.now() - begin < 2000) window.__reasoningPerformance.nativeRequest(tick)
          else window.__responseMs = -1
        }
        window.__reasoningPerformance.nativeRequest(tick)
      }, { once: true, capture: true })
    })
    await panel.getByRole('group', { name: '図解の段階', exact: true }).getByRole('button').nth(1).click()
    await page.waitForFunction(() => window.__responseMs !== null, null, { polling: 50 })
    const responseMs = await page.evaluate(() => window.__responseMs)
    assert.ok(responseMs >= 0 && responseMs <= 200)
    await seek(panel, 0)
    const beforePlay = await snapshot(panel)
    await panel.getByRole('button', { name: '図解を再生', exact: true }).click()
    await expect(panel).toHaveAttribute('data-mode', 'playing')
    const raf = await panel.evaluate(node => new Promise(resolve => {
      const times = [], phases = [], start = performance.now(); let previous = start
      function tick(now) {
        times.push(now - previous); previous = now; phases.push(node.querySelector('input[type=range]').value)
        if (now - start < 5500) window.__reasoningPerformance.nativeRequest(tick)
        else {
          const sorted = times.slice(1).sort((left, right) => left - right)
          resolve({ elapsed: now - start, samples: sorted.length, p95: sorted[Math.floor((sorted.length - 1) * .95)], max: sorted.at(-1), distinctPhases: new Set(phases).size })
        }
      }
      window.__reasoningPerformance.nativeRequest(tick)
    }))
    assert.ok(raf.p95 <= 32); assert.ok(raf.distinctPhases > 2)
    const afterPlay = await snapshot(panel)
    assert.ok(afterPlay.counters.requested > beforePlay.counters.requested)
    assert.ok(afterPlay.counters.executed > beforePlay.counters.executed, 'Instrumentation must observe real application callbacks while playing')
    await panel.getByRole('button', { name: '図解を一時停止', exact: true }).click()
    await expect(panel).toHaveAttribute('data-mode', 'manual')
    const paused = await idleProof(panel, id + ': manual pause')

    await seek(panel, 0)
    await panel.getByRole('button', { name: '図解を再生', exact: true }).click()
    await expect(panel).toHaveAttribute('data-mode', 'playing')
    await expect.poll(async () => Number(await panel.getByRole('slider', { name: '図解の再生位置', exact: true }).inputValue())).toBeGreaterThan(.1)
    const beforeExit = await snapshot(panel)
    assert.equal(beforeExit.mode, 'playing'); assert.equal(beforeExit.outsideViewport, false)
    const scrollAction = await panel.evaluate(async node => {
      const figure = node.closest('.reading-figure'), target = scrollY + figure.getBoundingClientRect().bottom + innerHeight
      window.scrollTo({ top: target, behavior: 'instant' })
      await new Promise(resolve => window.__reasoningPerformance.nativeRequest(() => window.__reasoningPerformance.nativeRequest(resolve)))
      let rect = node.closest('.aw-sticky').getBoundingClientRect(), fallbackToTop = false
      if (!(rect.bottom <= 0 || rect.top >= innerHeight)) {
        // At the end of a short document scrolling may clamp. The real top is
        // an alternative; subsequent geometry assertions still fail if visible.
        fallbackToTop = true; window.scrollTo({ top: 0, behavior: 'instant' })
      }
      return { requestedTop: target, fallbackToTop }
    })
    await expect.poll(() => panel.evaluate(node => { const rect = node.closest('.aw-sticky').getBoundingClientRect(); return rect.bottom <= 0 || rect.top >= innerHeight })).toBe(true)
    await expect(panel).toHaveAttribute('data-mode', 'manual')
    const outside = await idleProof(panel, id + ': actual viewport exit', true)
    report.performance.push({ id, responseMs, raf, beforePlay, afterPlay, paused, viewportExit: { beforeExit, scrollAction, idle: outside }, method: 'Native playback and actual UI pause/scroll. Click-handler to first range observation; native observer rAF callback intervals are not GPU frame times. Main-page application rAF request/execute/pending counts and phase are checked during each settled 500 ms idle window.' })
    await save()
  }
  await context.close()
  const critical = report.networkErrors.filter(entry => entry.type !== 'requestfailed' || ['script', 'stylesheet', 'font'].includes(entry.resourceType) || !String(entry.failure?.errorText).includes('ERR_ABORTED'))
  report.networkClassification = { criticalErrors: critical, otherRequestFailures: report.networkErrors.filter(entry => !critical.includes(entry)), scope: 'Any non-critical aborted fetch remains recorded with URL/type/time; script/style/font aborts remain failures. No context-close cause is inferred.' }
  assert.equal(critical.length, 0)
} catch (error) {
  report.errors.push({ error: error.stack || String(error) }); process.exitCode = 1
} finally {
  await browser.close()
  try { report.after = await identity(); assert.deepEqual(report.before, report.after); report.identityUnchanged = true }
  catch (error) { report.identityUnchanged = false; report.errors.push({ phase: 'final identity', error: error.stack || String(error) }); process.exitCode = 1 }
  report.finishedAt = new Date().toISOString(); await save()
  console.log(JSON.stringify({ output, errors: report.errors, cold: report.cold.map(item => ({ label: item.label, sceneGzip: item.sceneGzip, sharedGzip: item.sharedGzip, CLS: item.allCLS })), performance: report.performance }, null, 2))
}
