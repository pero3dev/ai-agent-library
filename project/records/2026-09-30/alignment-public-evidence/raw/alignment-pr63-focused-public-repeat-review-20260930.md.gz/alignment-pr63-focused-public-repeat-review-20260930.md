# PR #63 公開限定再実行 helper の独立レビュー

判定: **approved / low、must 0、should 0**。実レビュー日時: 2026-09-30T10:57:48Z。記録日時: 2026-09-30T10:59:14.072Z。

reviewer_run_id: `01a0ced7-e41c-70c1-904e-2ae30ff2fa4b:/root/inference_doc_review`

対象は一時 helper・作者 proof・generator の実行前点検です。製品・kit の変更承認、実再試験成功、画像判定、公開受入、原因確定を意味しません。

## 対象と結果

- helper: `C:\Users\81906\AppData\Local\Temp\alignment-pr63-focused-public-repeat.mjs` / SHA256 `215b666c8e13ab4898a903341770708028221079b2f6bb5688b49ad0f45e2c7e`
- authorProof: `C:\Users\81906\AppData\Local\Temp\alignment-pr63-focused-public-repeat-proof.json` / SHA256 `53a79e36dd29fccfacb70d2b9e35e609bedb14add9ec0d2df7e7b9d400df51a3`
- generator: `C:\dev\ai-agent-library\TEMP\prepare-alignment-public-retry.mjs` / SHA256 `eb7781887cef7499a9b9428a86f3cd6d5422c53ee1a091f7f2a77b7d3bc0d680`
- original: `C:\dev\ai-agent-library\scripts\diagram-release\verify-public.mjs` / SHA256 `309c2a106b7f25650e2640e9eee6cc525c50f80d310fea3835c646a959ccb806`

- helper（69–79、143–155、174–179、753–771 行）: 問題なし。
- author proof（5–16、66–74 行）: 問題なし。
- generator（11–34、38–44 行）: 問題なし。

## 独立確認

12 edits は import 絶対化7箇所、記録文・件数4箇所、選択 guard 1箇所だけです。逆適用で元全文バイト一致、順適用で helper バイト一致を独立再計算しました。7 import は元と同じモジュールを指します。構文確認は両スクリプトとも成功しました。

callback を実行しない登録検査で元107ケースの名前がすべて一意と確認しました。指定された「pretraining: all 23 stages 1440x1000 light DSF1」と「public assets: HTTP 200, nonempty bodies and matching MIME types」は各1件だけ存在します。前者は記事構造・原文・式を確認し、全図23段階の通常クリック、意味・形状・画像・配信検査を一から行います。後者が確認するのは、この profile から取得した assets です。

callback/assert/fixture、通常 click、15秒の action/expect 待機、45秒 navigation、30秒 asset request は変更されていません。CI の固定9 HTMLを入口で要求し、訪問した事前学習記事の BUILD_ID と原本 hash を照合する処理も保持しています。新規 output child は排他的に作成され、旧107ケースの証拠を上書きしません。

## 実行と判定の境界

呼出し元の計画どおり、両方の元 full run 完了後に、同じ merge/run/artifact/BUILD_ID を使い、WebKit で1回だけ実行する範囲の判定です。元失敗 raw を残し、成功しても「107全件の再実行成功」「原因判明」と扱いません。機械結果と実画像の独立レビューも別です。

本レビューで helper 実行、browser 起動、HTTP、full run 完了確認、画像実視認、原因調査は行っていません。製品・kit・Git・staged 内容への変更はありません。
