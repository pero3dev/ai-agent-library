import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const root = process.cwd(), temp = process.env.TEMP
const sourceFile = path.join(root, 'scripts/diagram-release/verify-public.mjs')
const original = readFileSync(sourceFile, 'utf8'), edits = []
let helper = original
const selectedCases = [
  'pretraining: all 23 stages 1440x1000 light DSF1',
  'public assets: HTTP 200, nonempty bodies and matching MIME types'
]
function replace(before, after) {
  assert.equal(helper.split(before).length, 2, before)
  helper = helper.replace(before, after); edits.push({ before, after })
}
for (const name of ['portable-paths', 'foundations-checks', 'inference-checks', 'training-checks', 'pretraining-checks', 'alignment-checks', 'known-site-observations']) {
  replace(`'./${name}.mjs'`, JSON.stringify(pathToFileURL(path.join(root, 'scripts/diagram-release', name + '.mjs')).href))
}
replace("evidenceClass: 'live-public-browser-and-http'", "evidenceClass: 'live-public-browser-and-http-focused-repeat'")
const oldIdentity = original.match(/^  identityNote: .+$/m)[0]
replace(oldIdentity, "  identityNote: 'The original admission checks still require the exact successful release and nine CI HTML identities. This focused run visits only the pretraining article and its delivered assets, not all nine public articles.',")
const oldScope = original.match(/^  scope: .+$/m)[0]
replace(oldScope, "  scope: 'Bounded repeat of one initial failed WebKit case, followed by its public assets check. The original case callback, stage/click waits, assertions, fixture, browser settings and timeouts are unchanged. Original 107-case raw remains failed and is not overwritten. This is not a full-suite rerun or a root-cause finding.',")
replace('  expectedCaseCount: 107,', '  expectedCaseCount: 2,\n  selectedCaseNames: ' + JSON.stringify(selectedCases) + ',')
replace('async function check(name, operation) {', 'async function check(name, operation) {\n  if (!' + JSON.stringify(selectedCases) + '.includes(name)) return')
let restored = helper
for (const { before, after } of [...edits].reverse()) {
  assert.equal(restored.split(after).length, 2)
  restored = restored.replace(after, before)
}
assert.equal(restored, original)
const sha = value => createHash('sha256').update(value).digest('hex')
const helperFile = path.join(temp, 'alignment-pr63-focused-public-repeat.mjs')
const proofFile = path.join(temp, 'alignment-pr63-focused-public-repeat-proof.json')
writeFileSync(helperFile, helper)
writeFileSync(proofFile, JSON.stringify({
  schemaVersion: 1, kind: 'author-generated-bounded-public-repeat-helper', createdAt: new Date().toISOString(),
  executed: false, independentReview: 'pending', sourceFile, sourceSHA256: sha(original), helperFile, helperSHA256: sha(helper),
  selectedCases, expectedCaseCount: 2, edits, exactReverseRestoration: true,
  preserved: ['Every original assertion and callback body', 'Ordinary trusted clicks and unchanged action/stability timeouts', 'The same fixed public URL and exact artifact admission', 'No local out/server/fake SHA', 'Original failed 107-case raw'],
  scope: 'Run only after both original full browser runs complete. This helper repeats the single failed full 23-stage profile and verifies its assets; it neither claims all 107 were rerun nor determines the initial timeout cause.'
}, null, 2) + '\n')
console.log(JSON.stringify({ helperFile, helperSHA256: sha(helper), sourceSHA256: sha(original), edits: edits.length, exactReverseRestoration: true, executed: false }))
