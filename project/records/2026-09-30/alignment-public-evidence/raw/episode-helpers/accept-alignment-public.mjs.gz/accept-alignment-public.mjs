import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import path from 'node:path'
import { TRACKED_ARTICLES, getDiagramArticleAcceptance, getDiagramArticleConfig } from '../website/lib/diagram-article-acceptance.mjs'

const directory = 'project/records/2026-09-30'
const record = `${directory}/alignment-public-evidence/final-review.json`
const review = JSON.parse(readFileSync(record, 'utf8'))
const index = JSON.parse(readFileSync(`${directory}/alignment-public-evidence/index.json`, 'utf8'))
assert.equal(review.status, 'approved')
assert.deepEqual(review.must, [])
assert.equal(index.publicAccepted, true)
assert.equal(review.release.mergeSha, 'b6686c92dbb678ea8b94eb12df37a33207c4c84b')
assert.equal(review.release.runId, 36702086701)
assert.equal(review.release.artifactId, 11090349965)
assert.equal(review.release.buildId, 'Iytr-Mx-iwwzxrZ8pUUHR')
assert.equal(TRACKED_ARTICLES.length, 9)
const changes = TRACKED_ARTICLES.map(article => {
  const current = getDiagramArticleAcceptance({ article })
  assert.equal(current.reviewRecorded, true)
  assert.equal(current.localRecorded, true)
  const file = getDiagramArticleConfig(article).evidencePath
  const value = JSON.parse(readFileSync(file, 'utf8'))
  value.public = {
    inputDigest: current.inputDigest, status: 'passed', checkedAt: review.checkedAt,
    commit: review.release.mergeSha,
    ci: 'https://github.com/pero3dev/ai-agent-library/actions/runs/36702086701',
    pages: 'https://github.com/pero3dev/ai-agent-library/actions/runs/36702086701/job/109848894912',
    browserRecord: record
  }
  return { file, value, snapshot: `${directory}/${path.basename(file, '.json')}-pr63.json` }
})
for (const { file, value, snapshot } of changes) {
  const serialized = JSON.stringify(value, null, 2) + '\n'
  if (existsSync(snapshot)) assert.equal(readFileSync(snapshot, 'utf8'), serialized)
  writeFileSync(file, serialized)
  writeFileSync(snapshot, serialized)
}
const articles = TRACKED_ARTICLES.map(article => ({ article, evidencePath: getDiagramArticleConfig(article).evidencePath, ...getDiagramArticleAcceptance({ article }) }))
assert.ok(articles.every(article => article.complete))
const snapshot = `${directory}/diagram-acceptance-pr63.json`
assert.ok(!existsSync(snapshot), 'The fixed acceptance snapshot must not be rewritten')
writeFileSync(snapshot, JSON.stringify({ schemaVersion: 1, verification: 'recorded-evidence-only', checkedAt: review.checkedAt, articles }, null, 2) + '\n')
console.log(JSON.stringify({ accepted: articles.length, snapshots: changes.length + 1, record }))
