import assert from 'node:assert/strict'
import fs from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'
const base = '5940334a6fd3aab8178cfeb8746a58c8b937d390'
const prep = JSON.parse(fs.readFileSync(path.join(tmpdir(),'alignment-d1-readonly-preparation-20260930.json'),'utf8'))
const ids=prep.diagrams.map(d=>d.id), json=v=>JSON.stringify(v,null,2)
const pick=(o,keys)=>Object.fromEntries(keys.map(k=>[k,o[k]]))
const hash=s=>createHash('sha256').update(s).digest('hex')
const original=file=>execFileSync('git',['-c','safe.directory=C:/dev/ai-agent-library','show',`${base}:${file}`],{encoding:'utf8'}).replace(/\r\n/g,'\n')
const read=file=>fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n')
const once=(s,b,a)=>{assert.equal(s.split(b).length,2,`Exact transform missing: ${b}`);return s.replace(b,a)}
const proofs=[]
function verify(file,restore){const current=read(file),old=original(file),restored=restore(current);assert.equal(restored,old,file);proofs.push({file,beforeSHA256:hash(old),candidateSHA256:hash(current),restoredSHA256:hash(restored),exactBeforeRestored:true})}
verify('website/lib/diagram-registry.mjs',s=>once(s,'const BINDINGS = {\n'+prep.diagrams.map(d=>`  '${d.id}': ${json(pick(d,['article','route','binding','stageCount','headings','sourceHeadings','blockGroups','blockTypes']))},`).join('\n'),'const BINDINGS = {'))
verify('website/lib/diagram-decoration.mjs',s=>{
  s=once(s,"'TrainingWalkthrough', 'PretrainingWalkthrough', 'AlignmentWalkthrough'].includes","'TrainingWalkthrough', 'PretrainingWalkthrough'].includes")
  return once(s,'const components = {\n'+ids.map(id=>`  '${id}': 'AlignmentWalkthrough',`).join('\n'),'const components = {')
})
verify('website/lib/mdx-safety.mjs',s=>{
  s=once(s,'const readingStages = {\n'+prep.diagrams.map(d=>`  '${d.id}': ${d.stageCount},`).join('\n'),'const readingStages = {')
  s=once(s,"'TrainingWalkthrough', 'PretrainingWalkthrough', 'AlignmentWalkthrough'])","'TrainingWalkthrough', 'PretrainingWalkthrough'])")
  s=once(s,"PretrainingWalkthrough: 'diagramId', AlignmentWalkthrough: 'diagramId', ReadingStep","PretrainingWalkthrough: 'diagramId', ReadingStep")
  return once(s,`const attributes = {\n  AlignmentWalkthrough: { diagramId: value => ${json(ids)}.includes(value) },`,'const attributes = {')
})
verify('website/mdx-components.js',s=>{
  s=once(s,"import { AlignmentWalkthrough } from './components/diagrams/alignment-walkthrough'\n",'')
  return once(s,'  PretrainingWalkthrough,\n  AlignmentWalkthrough,','  PretrainingWalkthrough,')
})
verify('website/lib/diagram-article-acceptance.mjs',s=>{
  const topics=Object.fromEntries(prep.article.sections.map(section=>[section.heading,prep.article.topics.filter(t=>t.heading===section.heading).map(t=>t.id)]))
  s=once(s,`export const ALIGNMENT_ARTICLE = '${prep.article.file}'\nexport const ALIGNMENT_EVIDENCE_PATH = 'project/records/2026-09-30/alignment-article-acceptance.json'\n`,'')
  s=once(s,'TRAINING_ARTICLE, PRETRAINING_ARTICLE, ALIGNMENT_ARTICLE])','TRAINING_ARTICLE, PRETRAINING_ARTICLE])')
  s=once(s,`const ALIGNMENT_TOPICS = ${json(topics)}\n\n`,'')
  s=once(s,`const ALIGNMENT_INPUT_FILES = [...SHARED_INPUT_FILES, 'website/components/diagrams/alignment-walkthrough.jsx',\n${ids.map(id=>`  'website/components/diagrams/${id}-walkthrough.jsx', 'website/components/diagrams/${id}.css', 'website/lib/${id}-model.mjs'`).join(',\n')}\n]\n`,'')
  s=once(s,`const configs = {\n  [ALIGNMENT_ARTICLE]: { primaryDiagramIds: ${json(ids)}, topics: ALIGNMENT_TOPICS, inputFiles: ALIGNMENT_INPUT_FILES, evidencePath: ALIGNMENT_EVIDENCE_PATH, requireReadingStage: true },`,'const configs = {')
  return once(s,"const overrideDirectories = {\n  [ALIGNMENT_ARTICLE]: 'llm-internals',",'const overrideDirectories = {')
})
const registry=JSON.parse(read('website/diagrams/registry.json')),beforeRegistry=JSON.parse(original('website/diagrams/registry.json'))
assert.deepEqual(registry.diagrams.filter(d=>!ids.includes(d.id)),beforeRegistry.diagrams)
const manifest=JSON.parse(read('website/diagrams/articles.json')),beforeManifest=JSON.parse(original('website/diagrams/articles.json'))
assert.deepEqual(manifest.articles.filter(a=>a.article!==prep.article.file),beforeManifest.articles)
const changed=execFileSync('git',['-c','safe.directory=C:/dev/ai-agent-library','diff','--name-only',base,'--','website','docs'],{encoding:'utf8'}).trim().split(/\r?\n/)
const expected=new Set(proofs.map(p=>p.file).concat('website/diagrams/registry.json','website/diagrams/articles.json',prep.article.file,'website/README.md','website/tests/unit/diagram-article-acceptance.test.mjs'))
assert.deepEqual(changed.filter(f=>!expected.has(f)),[],'Unexpected tracked runtime change; stop and re-review')
const result={schemaVersion:1,checkedAt:new Date().toISOString(),base,kind:'author-exact-shared-input-delta-proof',independent:false,files:proofs,existingRegistryEntries:beforeRegistry.diagrams.length,existingArticleAssignments:beforeManifest.articles.length,allExistingEntriesUnchanged:true,scope:'Five shared implementation files add only the explicit D1 bindings/dispatcher/acceptance paths. Old source bytes restore exactly; existing assignments/registry entries are equal. This does not prove runtime/visual/public acceptance.'}
fs.writeFileSync(path.join(tmpdir(),'alignment-shared-input-proof.json'),json(result)+'\n')
console.log(JSON.stringify({restoredSharedFiles:proofs.length,previousDiagrams:beforeRegistry.diagrams.length,previousArticles:beforeManifest.articles.length}))
