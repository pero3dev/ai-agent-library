import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'

const root = 'C:/dev/ai-agent-library', base = '5940334a6fd3aab8178cfeb8746a58c8b937d390'
const read = f => fs.readFileSync(path.join(root,f),'utf8').replace(/\r\n/g,'\n')
const json = f => JSON.parse(read(f))
const sha = s => createHash('sha256').update(s).digest('hex')
const git = args => execFileSync('git',['-c',`safe.directory=${root}`,'-C',root,...args],{encoding:'utf8',maxBuffer:20*1024*1024}).replace(/\r\n/g,'\n')
const old = f => git(['show',`${base}:${f}`])
const req = createRequire(path.join(root,'website/package.json'))
const imp = f => import(pathToFileURL(path.join(root,f)))
const dep = async name => (await import(pathToFileURL(req.resolve(name)))).default
const { unified } = await import(pathToFileURL(req.resolve('unified')))
const parser = unified().use(await dep('remark-parse')).use(await dep('remark-gfm')).use(await dep('remark-math')).use(await dep('remark-frontmatter'),['yaml'])
const pref = await imp('website/lib/alignment-preference-model.mjs')
const risk = await imp('website/lib/alignment-reward-risk-model.mjs')
const feed = await imp('website/lib/alignment-feedback-model.mjs')
const reg = await imp('website/lib/diagram-registry.mjs')
const deco = await imp('website/lib/diagram-decoration.mjs')
const safety = await imp('website/lib/mdx-safety.mjs')
const acceptance = await imp('website/lib/diagram-article-acceptance.mjs')
const proposal = json('project/records/2026-09-30/p1-interface-preparation/raw/alignment-d1-interface-proposal-20260930.json')
const prep = json('project/records/2026-09-30/p1-interface-preparation/raw/alignment-d1-readonly-preparation-20260930.json')
const article = prep.article.file, route = prep.article.route
const cases=[]
function check(name,fn) { fn(); cases.push({name,status:'passed'}) }
const close = (a,b) => assert.ok(Math.abs(a-b)<1e-12,`${a} != ${b}`)
const oracle=[]
for (const beta of [.5,1,2]) {
  // Expected values derive from the pair cross-product odds, not production log subtraction.
  const odds = ((.5*.25)/(.125*.25)) ** beta
  const expected={margin:Math.log(odds),preferenceProbability:odds/(1+odds),pairLoss:Math.log((odds+1)/odds)}
  check(`DPO closed form beta=${beta}`,()=>{
    for(const stage of [4,5,6]) {
      const frame=pref.alignmentPreferenceFrame(stage,{beta})
      for(const [key,value] of Object.entries(expected)) close(frame.pair[key],value)
      assert.deepEqual(frame.rows.map(r=>[r.policyProbability,r.referenceProbability]),[[.5,.25],[.125,.25]])
      assert.equal(frame.klDivergence,null);assert.equal(frame.expectedReward,null);assert.equal(frame.rlhfObjective,null)
      assert.ok(frame.normalizerTerms.every(t=>t.value===null&&t.cancelled===(stage===6)))
      assert.equal(frame.normalizerTerms[0].termId,frame.normalizerTerms[1].termId)
    }
    for(let stage=0;stage<4;stage++) assert.deepEqual(pref.alignmentPreferenceFrame(stage,{beta}),pref.alignmentPreferenceFrame(stage))
  }); oracle.push({beta,odds,...expected})
}
const fixture={beta:1,winner:{inputId:'same',policyProbability:.5,referenceProbability:.25},loser:{inputId:'same',policyProbability:.125,referenceProbability:.25}}
check('DPO symmetry, equal distributions, input not mutated, extreme valid tails',()=>{
  const before=JSON.stringify(fixture),p=pref.dpoPairTerms(fixture),q=pref.dpoPairTerms({...fixture,winner:fixture.loser,loser:fixture.winner})
  close(p.margin,-q.margin);close(p.preferenceProbability+q.preferenceProbability,1);close(q.pairLoss-p.pairLoss,p.margin)
  const equal=pref.dpoPairTerms({...fixture,winner:{...fixture.winner,policyProbability:.25},loser:{...fixture.loser,policyProbability:.25}})
  close(equal.pairLoss,Math.log(2));close(equal.preferenceProbability,.5)
  const tails=pref.dpoPairTerms({...fixture,winner:{...fixture.winner,policyProbability:Number.MIN_VALUE},loser:{...fixture.loser,referenceProbability:Number.MIN_VALUE}})
  assert.ok(Number.isFinite(tails.pairLoss));assert.equal(JSON.stringify(fixture),before)
})
const invalid=[]
for(const beta of [0,-1,NaN,Infinity,'1',null]) invalid.push({...fixture,beta})
for(const key of ['policyProbability','referenceProbability']) for(const value of [0,-.1,1.1,NaN,Infinity,'0.5',null]) invalid.push({...fixture,winner:{...fixture.winner,[key]:value}})
invalid.push({...fixture,loser:{...fixture.loser,inputId:'different'}},{...fixture,winner:{...fixture.winner,inputId:' '}},{...fixture,winner:{...fixture.winner,policyProbability:.9}},{...fixture,winner:{...fixture.winner,referenceProbability:.9}},{...fixture,extra:1},null,[])
check(`DPO rejects ${invalid.length} invalid inputs without clipping`,()=>invalid.forEach(value=>assert.throws(()=>pref.dpoPairTerms(value))))
check('Bradley Terry independent odds and common reward offset',()=>{
  for(const offset of [-100,0,100]) close(pref.bradleyTerryTerms(Math.log(3)+offset,offset).probability,3/4)
  for(const args of [[Infinity,0],[0,NaN],['1',0]]) assert.throws(()=>pref.bradleyTerryTerms(...args))
})
const models=[['alignment-preference',pref.alignmentPreferenceFrame,7],['alignment-reward-risk',risk.alignmentRewardRiskFrame,3],['alignment-feedback',feed.alignmentFeedbackFrame,5]]
let boundarySamples=0
check('All 15 stages and 36 midpoint sides are deterministic and clamp safely',()=>{
  for(const [id,frame,count] of models) {
    for(const phase of [-100,...Array.from({length:count},(_,i)=>i),100]) {
      const f=frame(phase);assert.equal(f.stage,Math.max(0,Math.min(count-1,Math.round(phase))));assert.ok(f.progress>=0&&f.progress<=1);assert.deepEqual(frame(phase),f)
    }
    for(let n=0;n<count-1;n++) for(const delta of [-.000001,0,.000001]) {const phase=n+.5+delta;assert.equal(frame(phase).stage,delta<0?n:n+1);boundarySamples++}
    for(const phase of [NaN,Infinity,-Infinity,'0',null]) assert.throws(()=>frame(phase))
  }
})
check('Qualitative risk and feedback do not invent scores or conflate source and granularity',()=>{
  for(let stage=0;stage<3;stage++) {const f=risk.alignmentRewardRiskFrame(stage);assert.equal(f.outputId,'answer-0');assert.ok(f.lanes.every(l=>l.value===null));for(const k of ['curve','turningPoint','optimum'])assert.equal(f[k],null);assert.equal(f.safetyGuarantee,false)}
  for(let stage=0;stage<5;stage++) {
    const h=feed.alignmentFeedbackFrame(stage,{labelSource:'human'}),a=feed.alignmentFeedbackFrame(stage,{labelSource:'ai'})
    if(stage<4)assert.deepEqual(h,a);else{assert.equal(a.effectiveLabelSource,'ai');delete h.effectiveLabelSource;delete a.effectiveLabelSource;assert.deepEqual(h,a)}
    assert.equal(h.marks.length,4);assert.equal(h.processRequiresMechanicalVerification,false);assert.equal(h.outcomeExcludesLearnedModel,false);assert.equal(h.harmlessnessGuarantee,false)
  }
})
check('Article changes are only adopted A1-A3 and three dates',()=>{
  let expected=old(article)
  for(const c of prep.corrections){assert.equal(expected.split(c.old).length,2);expected=expected.replace(c.old,c.replacement)}
  expected=expected.replace('last_updated: "2026-07-09"','last_updated: "2026-09-30"')
  expected=expected.split('\n').map(line=>/arxiv\.org\/abs\/(2305\.18290|2305\.20050)/.test(line)?line.replace('2026-07-09','2026-09-30'):line).join('\n')
  assert.equal(read(article),expected)
})
const assignment=json('website/diagrams/articles.json').articles.find(a=>a.article===article)
const allTopics=assignment.sections.flatMap(s=>s.topics)
check('42 adopted topics map to exactly 27 dynamic and 15 static entries',()=>{
  assert.equal(allTopics.length,42);assert.equal(allTopics.filter(t=>t.diagramId).length,27);assert.equal(allTopics.filter(t=>t.staticReason).length,15)
  for(const t of prep.article.topics){const current=allTopics.find(c=>c.id===t.id);assert.ok(current);assert.equal(current.label,t.topicAfterCorrectionsCandidate);if(t.coverage==='dynamic'){assert.equal(current.diagramId,t.diagramId);assert.deepEqual(current.stages,t.stageScope)}else assert.equal(current.staticReason,t.staticReason)}
  for(const d of proposal.diagrams){const entry=reg.diagramRegistry.diagrams.find(x=>x.id===d.id);for(const k of ['article','route','binding','stageCount','headings','sourceHeadings','blockGroups']) assert.deepEqual(entry[k],d.adopted[k]);assert.deepEqual(reg.assertDiagramSource(parser.parse(read(article)),entry).map(s=>s.body.map(n=>n.type)),d.adopted.blockTypes);assert.deepEqual([...new Set(allTopics.filter(t=>t.diagramId===d.id).flatMap(t=>t.stages))].sort((a,b)=>a-b),d.adopted.readingStages)}
})
const omitPositions = value=>Array.isArray(value)?value.map(omitPositions):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).filter(([k])=>k!=='position').map(([k,v])=>[k,omitPositions(v)])):value
const unwrap = node=>['AlignmentWalkthrough','ReadingStep'].includes(node.name)?node.children.flatMap(unwrap):[{...node,...(node.children?{children:node.children.flatMap(unwrap)}:{})}]
const visit=(node,predicate,values=[])=>{if(predicate(node))values.push(node);node.children?.forEach(child=>visit(child,predicate,values));return values}
const original=parser.parse(read(article)),baseTree=parser.parse(old(article))
check('Original four math nodes and Mermaid are unchanged',()=>{
  const key=n=>n.type==='math'||n.type==='code'&&n.lang==='mermaid'
  const current=visit(original,key).map(omitPositions);assert.equal(current.length,5);assert.deepEqual(current,visit(baseTree,key).map(omitPositions))
})
check('All eight enabled subsets preserve the complete AST and whole-block READ groups',()=>{
  for(let mask=0;mask<8;mask++){
    const registry=structuredClone(reg.diagramRegistry),tree=structuredClone(original)
    proposal.diagrams.forEach((d,i)=>registry.diagrams.find(x=>x.id===d.id).enabled=Boolean(mask&(1<<i)))
    deco.wrapRegisteredDiagrams(tree,route,registry);assert.deepEqual(omitPositions(unwrap(tree)[0]),omitPositions(original))
    for(const figure of visit(tree,n=>n.name==='AlignmentWalkthrough')){
      const id=figure.attributes.find(a=>a.name==='diagramId').value,d=proposal.diagrams.find(d=>d.id===id).adopted
      const groups=visit(figure,n=>n.name==='ReadingStep');assert.deepEqual(groups.map(n=>Number(n.attributes.find(a=>a.name==='step').value)),d.readingStages)
      assert.deepEqual(groups.map(n=>n.children.filter(c=>c.type!=='heading').length),d.blockGroups.flatMap(g=>g.map(x=>x.count)))
    }
  }
})
check('MDX fixed IDs and integer limits reject active expressions and escaped props',()=>{
  for(const d of proposal.diagrams)for(let stage=0;stage<d.adopted.stageCount;stage++)assert.deepEqual(safety.findUnsafeMdx(`<AlignmentWalkthrough diagramId="${d.id}"><ReadingStep step="${stage}">x</ReadingStep></AlignmentWalkthrough>`),[])
  for(const bad of ['<AlignmentWalkthrough diagramId={"alignment-preference"} />','<AlignmentWalkthrough diagramId="alignment-preference" {...x} />','<AlignmentWalkthrough diagramId="alignment-preference" onClick="x" />','<AlignmentWalkthrough diagramId="alignment-feedback"><ReadingStep step="5">x</ReadingStep></AlignmentWalkthrough>','<AlignmentWalkthrough diagramId="alignment-reward-risk"><ReadingStep step="-1">x</ReadingStep></AlignmentWalkthrough>'])assert.ok(safety.findUnsafeMdx(bad).length)
})
const shared=['website/lib/diagram-registry.mjs','website/lib/diagram-decoration.mjs','website/lib/mdx-safety.mjs','website/mdx-components.js','website/lib/diagram-article-acceptance.mjs']
const old8=acceptance.TRACKED_ARTICLES.filter(a=>a!==article).map(a=>({article:a,current:acceptance.getDiagramArticleAcceptance({repoRoot:root,article:a}),files:acceptance.getDiagramArticleConfig(a).inputFiles.map(file=>({file,beforeSHA256:sha(old(file)),afterSHA256:sha(read(file))}))}))
check('Old eight article bytes, registries, assignments and all non-five-shared inputs unchanged',()=>{
  for(const a of old8){assert.equal(read(a.article),old(a.article));assert.deepEqual(a.files.filter(f=>f.beforeSHA256!==f.afterSHA256).map(f=>f.file).sort(),[...shared].sort())}
  const oldReg=JSON.parse(old('website/diagrams/registry.json')),curReg=json('website/diagrams/registry.json')
  assert.deepEqual(curReg.diagrams.filter(d=>!d.id.startsWith('alignment-')),oldReg.diagrams)
  assert.deepEqual(json('website/diagrams/articles.json').articles.filter(a=>a.article!==article),JSON.parse(old('website/diagrams/articles.json')).articles)
})
const diffEvidence=shared.map(file=>({file,beforeSHA256:sha(old(file)),afterSHA256:sha(read(file)),diff:git(['diff',base,'--',file])}))
const newInput=acceptance.getDiagramArticleAcceptance({repoRoot:root,article})
const inputs=[...old8.map(a=>({article:a.article,inputDigest:a.current.inputDigest})),{article,inputDigest:newInput.inputDigest}]
const ownFiles=[article,...acceptance.getDiagramArticleConfig(article).inputFiles]
const hashes=ownFiles.map(file=>({file,sha256:sha(read(file))}))
const result={schemaVersion:1,kind:'independent-code-formula-integration-proof',reviewer:'/root/pretraining_visual_review',checkedAt:new Date().toISOString(),base,status:'passed',cases,oracle,invalidDpoInputs:invalid.length,boundarySamples,inputs,hashes,sharedDiffs:diffEvidence,old8:old8.map(a=>({...a,current:undefined})),visualStatus:'pending',scope:'Independent expected values use cross-product odds. Source/assignment/AST checked; five shared diffs reviewed as additive D1 integration. No browser, actual images, performance or public acceptance inferred.'}
const output=path.join(os.tmpdir(),'alignment-independent-code-proof.json');fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,passed:cases.length,oracle,boundarySamples,inputs},null,2))
