# D2 kit code review

判定: changes_requested、must3 / should1。確認時刻 2026-09-30T11:53:03.827Z、保存 2026-09-30T11:54:48.217Z。Reviewer 01a0ced7-e41c-70c1-904e-2ae30ff2fa4b:/root/inference_doc_review。

採択kit-plan/interface/storyboardと照合した静的・メモリ内検算です。callback、browser/public、画像視認は実行していません。対象hashと担当別実測は[JSON](reasoning-d2-kit-code-review.json)。並行修正中のREADME/manifestは承認対象外です。

| 重要度 | ファイル・行 | 指摘 | 最小修正 |
| --- | --- | --- | --- |
| must | predecessor-proof.mjs:105,117 | 本文とproofの連動改変で旧assert削除を受理 | D2proof全体の独立literal SHAと連動負例 |
| must | reasoning-checks.mjs:588,594,680–682 | S2印刷でCSS非表示selectorへtoBeVisibleを要求 | print時control非表示とscene意味検証を分離 |
| must | reasoning-checks.mjs:632–666,711 | 可視意味文言欠落・S1/2片側3欄欠落でも通過 | requiredLabels対応、6候補文言、variant毎3欄、境界実geometryと負例 |
| should | predecessor-proof.mjs:129–130 | 新14caseがindex81から連続しなくても通過 | slice(81,95)完全一致と分断負例 |

問題なし: 新14登録、計121、旧107→91→71→58の名前順保持、10routes、literal fixtureと採択案一致、6profiles/9stages/8READ、製品modelを期待値へimportしない構成、loopback限定local evidenceとpublic区分、既存adapter既定動作の保持。

M1は既存childがメモリ内で2種類の連動改変を再現。M2はbeforeprintとCSSを併読した矛盾。M3はevaluation S0/1/2/3 visibleText空、およびS1/2 metrics3欄が実際にvalidator通過。sequence S3でも時間費用/比率文言欠落が通過しました。製品自体の先行意味判定を取り消す指摘ではなくkitの検出不足です。

root/作者が修正中です。固定proof hash案に賛成します。水平strokeのbbox高さ0対策を含む新変更と全修正は別hashの再レビューが必要です。元の失敗記録は保存し、未実施のruntimeや公開を承認しません。
