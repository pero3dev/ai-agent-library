import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import path from 'node:path'

const [reviewJson, viewedLedger, reviewMarkdown] = process.argv.slice(2)
for (const file of [reviewJson, viewedLedger, reviewMarkdown]) assert.ok(file && existsSync(file))
const review = JSON.parse(readFileSync(reviewJson, 'utf8'))
assert.equal(review.status, 'approved')
const files = [], seen = new Set()
function add(file, storedName, kind) {
  const normalized = path.resolve(file).toLowerCase()
  if (seen.has(normalized)) return
  assert.ok(existsSync(file), file)
  seen.add(normalized); files.push({ file: path.resolve(file), storedName, kind })
}
for (const file of [reviewJson, viewedLedger, reviewMarkdown]) add(file, path.basename(file), 'independent-final-public-review')
const labels = { 'full-edge': 'Edge 初回107件', 'full-webkit': 'WebKit 初回107件', 'focused-webkit': 'WebKit 限定再実行2件' }
const browserResults = ['full-edge', 'full-webkit', 'focused-webkit'].map(kind => {
  const run = review.browserRuns.find(item => item.kind === kind)
  add(run.file, `${kind}/result.json`, 'live-public-browser-raw')
  return { kind, label: labels[kind], file: run.file }
})
for (const item of JSON.parse(readFileSync(viewedLedger, 'utf8'))) {
  add(item.file, `${path.basename(path.dirname(item.file))}/${path.basename(item.file)}`, 'actually-viewed-public-image')
  if (item.sourceCaseSnapshot) add(item.sourceCaseSnapshot, `case-snapshots/${path.basename(item.sourceCaseSnapshot)}`, 'immutable-completed-case-snapshot')
}
const temp = process.env.TEMP
// Preserve the independent review's intermediate observations as originals.
// The artifact proof is already in the archive's fixed base selection.
for (const entry of readdirSync(temp, { withFileTypes: true })) {
  if (entry.isFile() && /^alignment-pr63-public.*\.(?:json|mjs)$/.test(entry.name)
      && entry.name !== 'alignment-pr63-public-artifact-proof.json') {
    add(path.join(temp, entry.name), `independent-observations/${entry.name}`, 'independent-observation-original')
  }
}
for (const name of [
  'alignment-pr63-focused-public-repeat.mjs', 'alignment-pr63-focused-public-repeat-proof.json',
  'alignment-pr63-focused-public-repeat-review-20260930.md', 'alignment-pr63-focused-public-repeat-review-20260930.json'
]) add(path.join(temp, name), name, 'bounded-repeat-helper-and-independent-review')
for (const name of ['edge-public.log', 'webkit-public.log', 'webkit-focused-repeat.log']) {
  add(path.join(temp, 'alignment-pr63-public-20260930', name), name, 'live-public-process-log')
}
for (const name of ['prepare-alignment-public-retry.mjs', 'archive-alignment-public.mjs', 'select-alignment-public-archive.mjs', 'accept-alignment-public.mjs']) {
  add(path.join('TEMP', name), `episode-helpers/${name}`, 'episode-specific-helper-not-portable-entrypoint')
}
writeFileSync('TEMP/alignment-public-final-selection.json', JSON.stringify({ mergeSha: review.release.mergeSha, reviewJson, viewedLedger, files, browserResults }, null, 2) + '\n')
console.log(JSON.stringify({ files: files.length, browserRuns: browserResults.length, finalArchiveExecuted: false }))
