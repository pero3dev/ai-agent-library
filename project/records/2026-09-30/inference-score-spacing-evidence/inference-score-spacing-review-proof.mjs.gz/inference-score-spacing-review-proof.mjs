import {readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
import {execFileSync} from 'node:child_process'
import assert from 'node:assert/strict'
import path from 'node:path'
import {getDiagramArticleConfig} from 'file:///C:/dev/ai-agent-library/website/lib/diagram-article-acceptance.mjs'
const repo='C:/dev/ai-agent-library',tmp=process.env.TEMP,T=f=>path.join(tmp,'inference-score-spacing-review-'+f),require=createRequire(repo+'/website/package.json'),{unified}=require('unified'),parser=unified().use(require('remark-parse').default).use(require('remark-gfm').default).use(require('remark-math').default).use(require('remark-frontmatter').default,['yaml'])
const read=async f=>JSON.parse(await readFile(f,'utf8')),norm=v=>typeof v==='string'?v.replace(/\r\n?/g,'\n'):Array.isArray(v)?v.map(norm):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).filter(k=>k!=='position').sort().map(k=>[k,norm(v[k])])):v,rawsha=v=>createHash('sha256').update(v).digest('hex'),sha=v=>'sha256:'+rawsha(v)
const baseline=await read(T('pr61-inputs.json')),current=JSON.parse(execFileSync(process.execPath,['website/scripts/diagram-acceptance.mjs'],{cwd:repo,encoding:'utf8',windowsHide:true})),article='docs/11-llm-internals/inference-internals.md',config=getDiagramArticleConfig(article),registry=await read(repo+'/website/diagrams/registry.json'),assignments=await read(repo+'/website/diagrams/articles.json'),tree=parser.parse(await readFile(path.join(repo,article),'utf8')),assignment=assignments.articles.find(a=>a.article===article),selected=config.primaryDiagramIds.map(id=>registry.diagrams.find(d=>d.id===id)),files={}
for(const file of [...config.inputFiles,...config.optionalInputs]){try{files[file]=sha(norm(await readFile(path.join(repo,file),'utf8')))}catch(e){if(e.code!=='ENOENT')throw e;files[file]=null}}
const digest=()=>sha(JSON.stringify(norm({article:tree,assignment,registry:selected,files}))),currentDigest=digest();assert.equal(currentDigest,current.articles.find(a=>a.article===article).inputDigest)
const file='website/components/diagrams/inference-sampling.css',before=await readFile(T('pr61.css'),'utf8'),after=await readFile(path.join(repo,file),'utf8'),rule='.is-scene [data-comparison-kind="logit"] .is-score { font-size: 18px; }';assert.ok(after.includes(rule),'Expected scoped candidate rule missing; refusing old output as candidate');assert.equal(norm(after).replace(rule+'\n','').trimEnd(),norm(before).trimEnd(),'Unexpected product CSS delta')
files[file]=sha(norm(before));const reconstructedBeforeDigest=digest();assert.equal(reconstructedBeforeDigest,baseline.articles.find(a=>a.article===article).inputDigest)
const otherSeven=current.articles.filter(a=>a.article!==article).map(a=>{assert.equal(a.inputDigest,baseline.articles.find(b=>b.article===a.article).inputDigest);return{article:a.article,inputDigest:a.inputDigest}})
const report={checkedAt:new Date().toISOString(),file,rawBeforeSHA256:rawsha(before),rawAfterSHA256:rawsha(after),exactInsertedRule:rule,allOtherNormalizedCSSBytesEqual:true,currentDigest,reconstructedBeforeDigest,inputCount:Object.keys(files).length,otherSevenUnchanged:otherSeven}
await writeFile(T('proof.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2))
