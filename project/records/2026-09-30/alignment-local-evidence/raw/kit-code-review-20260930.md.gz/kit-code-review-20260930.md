# D1 公開検証 kit 独立コードレビュー

判定: **approved / low / must 0 / should 0**。実レビュー確定時刻: `2026-09-29T20:24:05.615Z`。基点: `5940334a6fd3aab8178cfeb8746a58c8b937d390`。最終 manifest: `40cca5a2f969f4c0385fac358cf4988decb6f72076c5b91e1b52fe22153adee9`。

## 範囲と独立性

対象は他担当が作成した公開検証 kit、履歴証明、manifest、README、portable unit と localhost CI 入口です。レビュアーは D1 interface 案と alignment-preference 製品の作者のため、それらの自己承認を含めません。製品・kit・repo tests・Git は編集せず、OS TEMP の helper と本記録だけを作成しました。全記事の意味的承認、実ブラウザー・画像可読性・CI・公開受入は別の判定です。

## 確認結果

- **Predecessor preservation**: D1 inverse reconstructs 11 protected release/module/helper files byte-for-byte against actual Git base, including the complete prior predecessor helper prefix and C2 proof. Three entrypoint diffs contain only declared D1 registration, ninth route, report counts and the sole control migration. Existing C2-to-C1 and protected historical segments also verify.
- **Case and route inventory**: Callback-free registration of actual runner gives 107 unique names. Remove 16 additions and inverse only the control name at old position 89 to recover actual Git 91 names; remove C2 20 and C1 13 to recover ordered 71 and 58. Nine exact CI artifact routes agree in extractor, collector and runner. Embeddings remains outside artifact set and retains HTTP/MIME/nonempty-body/BUILD_ID/zero-heavy checks.
- **Public identity boundary**: Collector successful-main-run/SHA/deploy/artifact binding and runner public HTML/Flight BUILD_ID plus exact CI HTML hash checks remain protected. No skip flag, arbitrary public base, all-zero SHA shortcut, identity assertion removal or local artifact substitution was introduced.
- **Literal oracle**: alignment-checks imports only node:assert/strict. DPO expectations are fixed fractions and logarithms independent of product helpers. BT 3/4 is distinct from DPO; fixed pi_theta=(1/2,1/8), pi_ref=(1/4,1/4), ratios 2 and 1/2, beta .5/1/2 give preference 2/3,4/5,16/17 and loss ln(3/2),ln(5/4),ln(17/16). Same-input paired Z terms, full KL unknown, pair loss versus expectation and visible caveats are asserted.
- **Conceptual fixture**: The same answer feeds proxy and separate quality lanes; no numerical true-quality oracle or guaranteed mitigation is manufactured. Source and granularity are orthogonal, the human process-label caveat is required, and outcome/process marks and non-universal side effects are independently fixed.
- **Coverage and visible checks**: Final module registers 6 screen-profile cases + 3 semantic cases + keyboard/modal + READ + 3 native clocks + noJS + print = 16. All 15 stages/READ stops, 72 midpoint forward/reverse visits, selector values at active stages plus 31 full selected-state grid cells, visible SVG/text and raw data are covered. Original 9 H3, 4 equations and Mermaid are retained; 390px original DPO formula keyboard both ends, fractions and subscripts are checked. Whole-scene and viewport PNG stay separate; visible-geometry observations leave image review pending.
- **Local adapter boundary**: Only HTTP localhost/127.0.0.1/[::1] roots are accepted, with restricted optional basePath. The same 16 callbacks run without deployed SHA or artifact evidence, and local report class is explicit. Tested external host/scheme/path, path traversal and public evidence classes fail before a browser launch. Existing public helper assertions, network failures and native clock behavior are retained.
- **Flat provenance**: Current 18-file inventory is hash checked; D1 flat sidecar restores C2 then existing C1. No self-hash, current manifest hash or nested old manifest body enters the proof. Old C2 proof bytes and predecessor manifest hash match actual Git base.

## 独立実行

- portable unit を独立に再実行し **30/30、exit 0**。全 site build や公開ブラウザーは起動していません。
- 自作 helper は **11 群 / 53 負例、exit 0**。最終 manifest と 18 inventory の byte/hash、実 Git 11 ファイルとの完全一致、107→91→71→58、literal 数値・概念 fixture、loopback 境界、flat proof を検査しました。
- unit の後に変更されたのは README と manifest の状態表示だけです。最終 40cca5a2 版で helper を再実行し、コードと unit の hash 不変を確認しました。
- 各入力 hash とログ/helper/result のパス・hash は同名 JSON に収録しています。元の作者チェックや初期 Edge 出力を最終版の成功へ読み替えていません。

## レビュー中に解消した指摘

1. README の「alignment-theory は現在、無図対照」を root が C1 時点の履歴へ訂正し、現行 embeddings 移行へ接続しました。
2. manifest の版表示を root が `D1-candidate-pending-independent-review` へ同期しました。履歴の schema と hash は保持されています。

情報のみ: extractor の混在 BUILD_ID エラー文には履歴由来の eight が残りますが、固定 9 route と同一 BUILD_ID の実 assert は維持され、負例も失敗します。受入範囲を変える指摘ではありません。

## 残る受入

最終コード版のローカルブラウザー、独立画像レビュー、最終記事・統合 tree の正式レビュー、実 CI/Pages と 107 件の公開検査、公開画像の独立受入は root の別記録が正本です。このコードレビューだけで公開完了にしません。P1 全 15 記事の公開受入で停止し、P2 へ進みません。

## 入力ファイル

| repo 相対パス | bytes | SHA256 |
| --- | ---: | --- |
| `scripts/diagram-release/collect-deployment.ps1` | 12529 | `6fdd080b56c215f43c352c5cd06827a890cdaa51bf8908304d70e01594326c19` |
| `scripts/diagram-release/extract-ci-html.mjs` | 4362 | `bab471e15e441d46b6dd6c52efb30996b76981c8cb4ec15c0224404d241cc309` |
| `scripts/diagram-release/verify-public.mjs` | 64053 | `309c2a106b7f25650e2640e9eee6cc525c50f80d310fea3835c646a959ccb806` |
| `scripts/diagram-release/inference-checks.mjs` | 31874 | `9f52ca50576dcadc6010b60e30561b768a16b5da0ea8765952e2fc2c5c69e201` |
| `scripts/diagram-release/foundations-checks.mjs` | 26410 | `cab2f1e086b6913de48bb2c47978ad733d3f04dca2bf4934b48c818ca9859398` |
| `scripts/diagram-release/known-site-observations.mjs` | 130 | `1e4865a7c6c9c83af239a2b395e9f0100d03bae88a776ebbac6c48883fb31659` |
| `scripts/diagram-release/check-preparation.mjs` | 15841 | `02ec3e179cea91c68611517844e28bb43104efcec8d5621d4ecff79ce87c3256` |
| `scripts/diagram-release/README.md` | 22879 | `b6c2829aaaf39281dfc32e9111d8a2294108f18037df59a572c88419e55a8c00` |
| `scripts/diagram-release/portable-paths.mjs` | 7151 | `eb3bab3ad3e9bfcffbd2071d23c321ae71abb4a5a7fa78dee1706ef9fd1abd4a` |
| `tests/unit/diagram-release-portable.test.mjs` | 30487 | `ffc69e4b9d32209c349b9262b72609ba0be9045a12dccb82265370891ed5937c` |
| `scripts/diagram-release/training-checks.mjs` | 27264 | `83bd24b85bb4179f643d4a8ba1727a87c305ed6f8b7859e410ace76c70f5e79e` |
| `scripts/diagram-release/pretraining-checks.mjs` | 47725 | `4fc7051874e6dfdfa2b92052e7ebf237808237a7a2680c85a4008f187fc5de69` |
| `scripts/diagram-release/predecessor-proof.mjs` | 6432 | `bad076d8cee2beb374de194d0cabae8e7183b3c87b7bc6531022f1626e95e443` |
| `scripts/diagram-release/c2-predecessor-proof.json` | 16010 | `a464b808ad76f33ec36df3a3e305b3847aeb056c32b58a5cfb62aa5e4ef77cea` |
| `scripts/diagram-release/alignment-checks.mjs` | 40400 | `c2dec4a5e62f2f557de44fbfff9a4d9b4a10aa94d449356268ebf9a267c74717` |
| `scripts/diagram-release/local-alignment-adapter.mjs` | 18686 | `c5170691e034afa1378b0a1d425b08ca9df75f04eca256fb4782d06baabf65a1` |
| `scripts/diagram-release/d1-predecessor-proof.json` | 14612 | `a2d25ae6426d42fa9961cef797918861253758cc6a0a245968981f24b12f6276` |
| `website/tests/browser/alignment.spec.mjs` | 1594 | `69332439b02df0ae8ca0016f2f7f7062010acfbf719bf1e64c161438190a6b0a` |
| `scripts/diagram-release/source-mapping.json` | 58114 | `40cca5a2f969f4c0385fac358cf4988decb6f72076c5b91e1b52fe22153adee9` |
