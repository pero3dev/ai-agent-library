# D2 final local review

**approved / low — must 0、should 0。ローカル受入として問題なし。公開受入は未実施です。**

Reviewer: 01a0ced7-e41c-70c1-904e-2ae30ff2fa4b:/root/inference_doc_review
Reviewed: 2026-09-30T12:28:37.439Z
Recorded: 2026-09-30T12:31:01.138Z
BUILD_ID: ay8Xdd-uRIpIwdWdgy70j

| 対象 | 判定・根拠 |
| --- | --- |
| D2本文・AST・2図9段階 | 原文不変、43論点と8READ/manual1の意味を保持。CoT限定表現のshouldを修正し最終画像で確認。 |
| kit M1/M2/M3・S1 | 解消。固定proof・旧107保護、新14連続配置、印刷非表示selectと可視SVG、独立した可視意味oracleを確認。 |
| 画像 | 実視認122枚＝旧83＋最終39（WebKit34、Edge preflight5）。旧83のうち1枚はfailed print診断用であり、成功証拠へ変更しない。 |
| ブラウザー | 全Edge 347成功/既定5skip。D2 raw両engine各14成功、同HTML。追加fallbackは両engine各2成功として別集計。 |
| 性能 | 実chunk gzip 17,309 B/共有21,954 B、CLS0、操作14.2/10.1 ms、rAF p95両7.1 ms。両図の停止・実画面外移動後500 ms以上でrequest/execute/pending0、phase不変。 |
| 旧9記事 | 132固有/共通入力を独立比較。記事固有入力・27 registry・9 assignments不変、共有5追加だけを意味レビュー。PR63の公開受入は歴史証拠として限定継承。 |

全結果を10input・10HTML・BUILDに結合し、性能before/after同一性と実chunkのhash/gzipを独立検算しました。画像・case raw・全ログ・性能raw・先行レビューの絶対path/SHAはJSONとcombined ledgerへ記録しています。

性能は単独のWindows Edge/localhost/無制限CPUネットワーク条件です。rAFはGPU描画時間ではなくcallback間隔、gzipは配信実転送量ではなく生成chunkの計算値です。非criticalなfetch ERR_ABORTED38件は原因未断定のまま原本に保持しています。

実画像確認とブラウザー自動試験の運動結果は区別します。WebKit emulationは実機Safariではなく、DSF2はブラウザーUIの200%拡大ではありません。公開後は同じ新artifactのEdge/WebKit各121件と独立公開画像受入が必要です。

総合判定: ローカル受入可。公開受入を兼ねません。
