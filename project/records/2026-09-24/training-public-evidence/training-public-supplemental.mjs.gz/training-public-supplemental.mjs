import assert from 'node:assert/strict'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import path from 'node:path'
import {fileURLToPath,pathToFileURL} from 'node:url'
const repo='C:/dev/ai-agent-library', base='https://pero3dev.github.io/ai-agent-library'
const outputRoot=process.argv[2], output=path.join(outputRoot,'training-public-supplemental')
await mkdir(output,{recursive:true})
const sha=b=>createHash('sha256').update(b).digest('hex')
const evidenceFile=path.join(outputRoot,'artifact-evidence.latest.json'),evidenceBytes=await readFile(evidenceFile),artifact=JSON.parse(evidenceBytes)
assert.equal(artifact.mergeSha,'517dc8b5166bd7b0c85baef3800d7fe57bac7b31');assert.equal(artifact.expectedBuildId,'EliX86DAnCpMQHOKIyCQx');assert.equal(artifact.documents.length,7)
const {lockedPlaywright}=await import(pathToFileURL(path.join(repo,'scripts/diagram-release/portable-paths.mjs')))
const pw=await lockedPlaywright(repo), expect=pw.expect.configure({timeout:15000}),browser=await pw.chromium.launch({channel:'msedge',headless:true})
const result={schemaVersion:1,evidenceClass:'independent-public-supplemental-capture',startedAt:new Date().toISOString(),reviewer:'/root/training_public_acceptance',mergeSha:artifact.mergeSha,expectedBuildId:artifact.expectedBuildId,artifactEvidenceSHA256:sha(evidenceBytes),artifactEvidenceFile:evidenceFile,scriptSHA256:sha(await readFile(fileURLToPath(import.meta.url))),browser:{engine:'chromium',channel:'msedge',version:browser.version()},profile:{width:1440,height:1000,theme:'light',deviceScaleFactor:1,reducedMotion:'reduce'},screenshots:[],before:[],after:[],pageErrors:[],consoleErrors:[]}
const ids=html=>[...new Set([...html.replaceAll('\\"','"').matchAll(/"b":"([A-Za-z0-9_-]+)"/g)].map(m=>m[1]))]
async function document(response,expected){const body=await response.body(),row={route:expected.route,url:response.url(),status:response.status(),contentType:response.headers()['content-type'],sha256:sha(body),buildIds:ids(body.toString('utf8')),checkedAt:new Date().toISOString()};assert.equal(row.status,200);assert.match(row.contentType,/text\/html/);assert.equal(row.sha256,expected.htmlSHA256);assert.deepEqual(row.buildIds,[artifact.expectedBuildId]);return row}
const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:'light',deviceScaleFactor:1,reducedMotion:'reduce'})
try{
 result.before=await Promise.all(artifact.documents.map(async d=>document(await context.request.get(base+d.route),d)))
 const page=await context.newPage();page.on('pageerror',e=>result.pageErrors.push(e.message));page.on('console',m=>{if(m.type()==='error')result.consoleErrors.push(m.text())})
 await page.addInitScript(()=>localStorage.setItem('theme','light'))
 const expected=artifact.documents.find(d=>d.route.endsWith('/transformer-architecture'))
 result.pageDocument=await document(await page.goto(base+expected.route,{waitUntil:'networkidle'}),expected)
 await page.evaluate(()=>document.fonts.ready)
 for(const [figure,label] of [['transformer-io','出力'],['transformer-position','RoPE'],['self-attention','スコア'],['transformer-block','FFN']]){
  const root=page.locator(`.reading-figure[data-diagram-id="${figure}"]`),panel=root.locator('.aw-sticky > .aw-diagram')
  await expect(root).toHaveAttribute('data-ready','true')
  await panel.getByRole('group',{name:'図解の段階',exact:true}).getByRole('button',{name:label,exact:true}).click()
  await expect(panel).toHaveAttribute('data-stage','2');await expect(panel).toHaveAttribute('data-mode','manual');await panel.scrollIntoViewIfNeeded()
  const name=`public-review-${figure}-stage-2-1440x1000-light`
  const png=await page.screenshot({path:path.join(output,name+'.png'),fullPage:false})
  result.screenshots.push({figure,stage:2,kind:'viewport',file:name+'.png',sha256:sha(png),width:png.readUInt32BE(16),height:png.readUInt32BE(20)})
  const svg=panel.locator('svg.aw-scene'),original=await page.evaluate(()=>({x:scrollX,y:scrollY}))
  try{
   await svg.evaluate(n=>scrollTo({top:scrollY+n.getBoundingClientRect().top-86,behavior:'instant'}))
   const bounds=await svg.boundingBox();assert.ok(bounds.x>=0&&bounds.y>=64&&bounds.x+bounds.width<=1440&&bounds.y+bounds.height<=1000)
   const clip={x:Math.floor(bounds.x),y:Math.floor(bounds.y),width:Math.ceil(bounds.x+bounds.width)-Math.floor(bounds.x),height:Math.ceil(bounds.y+bounds.height)-Math.floor(bounds.y)}
   const scene=await page.screenshot({path:path.join(output,name+'-scene.png'),clip,fullPage:false})
   assert.equal(scene.readUInt32BE(16),clip.width);assert.equal(scene.readUInt32BE(20),clip.height)
   result.screenshots.push({figure,stage:2,kind:'completeScene',file:name+'-scene.png',sha256:sha(scene),width:scene.readUInt32BE(16),height:scene.readUInt32BE(20),bounds,clip,stylesModified:false,viewportModified:false,originalScroll:original,captureScroll:await page.evaluate(()=>({x:scrollX,y:scrollY})),labels:await svg.locator('text').allTextContents()})
  }finally{await page.evaluate(p=>scrollTo({left:p.x,top:p.y,behavior:'instant'}),original)}
 }
 result.after=await Promise.all(artifact.documents.map(async d=>document(await context.request.get(base+d.route),d)))
 assert.deepEqual(result.pageErrors,[]);assert.deepEqual(result.consoleErrors,[])
 result.status='passed'
}catch(error){result.status='failed';result.error=error.stack;process.exitCode=1}
finally{await browser.close();result.finishedAt=new Date().toISOString();await writeFile(path.join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,status:result.status,images:result.screenshots.length,error:result.error}))}