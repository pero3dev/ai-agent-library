import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { TRACKED_ARTICLES, REASONING_ARTICLE, getDiagramArticleConfig, getDiagramArticleAcceptance } from '../website/lib/diagram-article-acceptance.mjs'
const repo=process.cwd(),base='b6686c92dbb678ea8b94eb12df37a33207c4c84b',sha=b=>createHash('sha256').update(b).digest('hex'),lf=b=>b.toString().replaceAll('\r\n','\n')
const current=file=>fs.readFileSync(path.join(repo,file)),prior=file=>execFileSync('git',['-c','safe.directory='+repo.replaceAll('\\','/'),'show',base+':'+file],{maxBuffer:8*1024*1024,windowsHide:true})
const shared=['website/lib/diagram-registry.mjs','website/lib/diagram-decoration.mjs','website/lib/mdx-safety.mjs','website/lib/diagram-article-acceptance.mjs','website/mdx-components.js']
const registry=JSON.parse(current('website/diagrams/registry.json')),oldRegistry=JSON.parse(prior('website/diagrams/registry.json'))
assert.deepEqual(registry.diagrams.filter(d=>d.article!==REASONING_ARTICLE),oldRegistry.diagrams)
const assignments=JSON.parse(current('website/diagrams/articles.json')),oldAssignments=JSON.parse(prior('website/diagrams/articles.json'))
assert.deepEqual(assignments.articles.filter(d=>d.article!==REASONING_ARTICLE),oldAssignments.articles)
const cache=new Map(),compare=file=>{
 if(!cache.has(file)){const before=lf(prior(file)),after=lf(current(file));cache.set(file,{file,beforeSHA256:sha(before),afterSHA256:sha(after),unchanged:before===after})}
 return cache.get(file)
}
const old9=TRACKED_ARTICLES.filter(article=>article!==REASONING_ARTICLE).map(article=>{
 const files=[article,...getDiagramArticleConfig(article).inputFiles].map(compare)
 assert.deepEqual(files.filter(f=>!f.unchanged).map(f=>f.file).sort(),[...shared].sort())
 return {article,inputDigest:getDiagramArticleAcceptance({article}).inputDigest,files}
})
assert.equal(old9.length,9)
const inputs=TRACKED_ARTICLES.map(article=>({article,inputDigest:getDiagramArticleAcceptance({article}).inputDigest}))
const buildId=current('website/.next/BUILD_ID').toString().trim()
const html=TRACKED_ARTICLES.map(article=>{
 const route='/docs/'+article.replace(/^docs\/\d+-/,'').replace(/\.md$/,'');const bytes=current('website/out'+route+'.html')
 const ids=[...new Set([...bytes.toString().replaceAll('\\"','"').matchAll(/"b":"([A-Za-z0-9_-]+)"/g)].map(m=>m[1]))]
 assert.deepEqual(ids,[buildId]);return{article,route,bytes:bytes.length,sha256:sha(bytes)}
})
const result={evidenceClass:'local-source-and-static-identity',checkedAt:new Date().toISOString(),base,buildId,oldRegistryEntriesUnchanged:oldRegistry.diagrams.length,oldAssignmentsUnchanged:oldAssignments.articles.length,sharedChanged:shared,old9,inputs,html,hashes:[...new Set(TRACKED_ARTICLES.flatMap(a=>[a,...getDiagramArticleConfig(a).inputFiles]))].map(file=>({file,sha256:sha(lf(current(file)))})),limitations:['Shared additions need independent source review.','Static input comparison is not runtime, visual or public acceptance.']}
const file=path.join(os.tmpdir(),'reasoning-d2-input-comparison.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({file,sha256:sha(fs.readFileSync(file)),buildId,old9:old9.length,unchangedRegistry:result.oldRegistryEntriesUnchanged,unchangedAssignments:result.oldAssignmentsUnchanged,inputs:inputs.length}))
