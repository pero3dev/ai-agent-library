# D1 composed independent local review

Checked 2026-09-30T09:15:22.545Z; reviewer /root/pretraining_visual_review. **approved / low; must 0, should 0.** This approves the local scope, not the formal frozen-tree article or public release.

- Independent code/formula/integration proof: 14 groups; 27 invalid DPO inputs; 36 midpoint samples; all 15 stages and all eight AST enable subsets. DPO expected values used independent odds 4^β. All 42 topics (27 dynamic / 15 static), 15 READ stages, A1–A3 corrections, four equations and Mermaid preserved.
- Completed browser evidence: Edge 333 passed / 5 existing skips / 0 failed (338 total); final WebKit 42/42 (16 D1 + 26 math); final Edge selector-grid 3/3. Final β grid has 21 states and source grid 10 states per engine. Initial Edge and final grid fixtures remain distinct.
- Actually viewed **168 unique PNGs: Edge 84 / WebKit 84**, 140 full-scene / 28 viewport. Initial 96 plus 36 additional images per engine. Generated counts are separately recorded: initial 96, Edge D1 216, final WebKit D1 216, final Edge grid 22. No old-eight image is counted again.
- No confirmed visual or semantic defect. Full scenes, modal, low desktop, 960×540 DSF2, 390 dark, no-JS and print checked. Bbox candidates were judged by actual glyphs. Low-height viewport captures may show a partially scrolled figure; full-scene evidence does not imply the entire figure fits in one viewport.
- Performance remains the earlier independent low-load run: scene gzip 26,805 B / common 21,892 B; CLS 0; response 12.8–13.5 ms; rAF P95 7.1–7.2 ms. These are local emitted-chunk/loopback/callback measurements, not public transfer, GPU frame or device performance. All 30 aborted fetches (17 URLs) are retained and classified to existing HTML/page data; cause not established. No script/style/font/console/page error.
- Current BUILD **XJR9sUrJP0VbXQCKQiQ8F**, all nine input digests, all nine HTML hashes and source hashes match the frozen code/capture/performance evidence. Final kit manifest 40cca5a2f969f4c0385fac358cf4988decb6f72076c5b91e1b52fe22153adee9.
- Old-eight carry is limited: unchanged article and non-five-shared inputs plus independently reviewed additive shared integration, prior PR62 independent public acceptance and current full Edge regression. Their complete input digests changed with the shared files. This is not a fresh full old-eight WebKit or image acceptance.
- Initial supplementary helper 404s remain in their original evidence; those images serve visual review only. Final kit failures are zero except the explicitly expected no-JS script block.

Sources previously checked: [DPO paper](https://arxiv.org/html/2305.18290), [Let's Verify Step by Step](https://arxiv.org/html/2305.20050v1). No product, prose, kit or Git edits were made by this reviewer.

Evidence files:

- Structured review: C:/Users/81906/AppData/Local/Temp/alignment-independent-final-review.json
- Actual-view ledger: C:/Users/81906/AppData/Local/Temp/alignment-independent-final-viewed-images.json
- Final identity and nine article digests: C:/Users/81906/AppData/Local/Temp/alignment-independent-final-identity.json
- Completed case inventory: C:/Users/81906/AppData/Local/Temp/alignment-independent-final-case-inventory.json
- Independent code proof: C:/Users/81906/AppData/Local/Temp/alignment-independent-code-proof.json
- Performance raw: C:/Users/81906/AppData/Local/Temp/alignment-independent-performance/2026-09-29T20-27-02.077Z/result.json
- Aborted-fetch classification: C:/Users/81906/AppData/Local/Temp/alignment-independent-performance-network-classification.json
- Prior bounded carry: C:/Users/81906/AppData/Local/Temp/inference-score-spacing-public-pr62-review.json

Unperformed: formal frozen-tree article review; current CI/Pages/public acceptance; physical iPhone/Safari and real screenreader; full old-eight WebKit rerun; GPU/paint or throttled/device benchmarks.
