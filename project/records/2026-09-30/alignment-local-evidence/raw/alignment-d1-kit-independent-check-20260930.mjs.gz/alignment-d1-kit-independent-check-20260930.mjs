import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root=process.cwd(), kit=path.join(root,'scripts/diagram-release'), base='5940334a6fd3aab8178cfeb8746a58c8b937d390';
const hash=x=>createHash('sha256').update(x).digest('hex');
const read=f=>fs.readFileSync(path.join(kit,f),'utf8');
const git=f=>execFileSync('git',['-c','safe.directory='+root.replaceAll('\\','/'),'show',base+':scripts/diagram-release/'+f],{cwd:root,encoding:'utf8',windowsHide:true});
const load=f=>import(pathToFileURL(path.join(kit,f)).href);
const [proofs,a,l,i,f,t,p]=await Promise.all(['predecessor-proof.mjs','alignment-checks.mjs','local-alignment-adapter.mjs','inference-checks.mjs','foundations-checks.mjs','training-checks.mjs','pretraining-checks.mjs'].map(load));
const manifest=JSON.parse(read('source-mapping.json')), d1=JSON.parse(read('d1-predecessor-proof.json')), c2=JSON.parse(read('c2-predecessor-proof.json'));
const sources=Object.fromEntries(fs.readdirSync(kit).filter(x=>fs.statSync(path.join(kit,x)).isFile()).map(x=>[x,read(x)]));
const report={kind:'independent-D1-kit-offline-probes',startedAt:new Date().toISOString(),base,networkExecuted:false,browserExecuted:false,productModelImported:false,groups:[],negativeProbes:0};
const group=async(name,fn)=>{await fn();report.groups.push({name,status:'passed'});};
const reject=(fn)=>{assert.throws(fn);report.negativeProbes++;};
try {
await group('Current 18-file manifest, LF, and exact copied bytes',()=>{
 const entries=[...manifest.sourceFiles,...manifest.addedFiles];assert.equal(entries.length,18);
 report.inputFiles=entries.map(x=>{const rel=x.location==='repository'?x.file:'scripts/diagram-release/'+x.file;const b=fs.readFileSync(path.join(root,rel));assert.equal(hash(b),x.portableSHA256);assert.ok(!b.includes(13)&&b.at(-1)===10&&b.at(-2)!==10);return{file:rel,bytes:b.length,sha256:hash(b)};});
 report.inputFiles.push({file:'scripts/diagram-release/source-mapping.json',bytes:Buffer.byteLength(sources['source-mapping.json']),sha256:hash(sources['source-mapping.json'])});
});
let prior;
await group('D1 reverse reconstruction matches actual Git base in all 11 protected files',()=>{
 prior=proofs.restoreC2ReleaseBodies(sources,d1);
 const fixed=['extract-ci-html.mjs','collect-deployment.ps1','verify-public.mjs','inference-checks.mjs','foundations-checks.mjs','training-checks.mjs','pretraining-checks.mjs','known-site-observations.mjs','portable-paths.mjs','c2-predecessor-proof.json','predecessor-proof.mjs'];
 report.gitBaselineComparison=fixed.map(file=>{const actual=git(file);assert.equal(prior[file],actual,file);return{file,restoredSHA256:hash(prior[file]),actualGitSHA256:hash(actual)};});
 assert.equal(hash(git('source-mapping.json')),d1.predecessorManifestSHA256);
});
await group('Existing C2-to-C1 proof and protected bodies remain valid after D1 reversal',()=>{
 const older=proofs.restoreC1ReleaseBodies(prior,c2);
 for(const segment of manifest.protectedSegments){const body=older[segment.file], start=body.indexOf(segment.start), marker=segment.portableEnd||segment.end, end=marker?body.indexOf(marker,start):body.length;assert.ok(start>=0&&end>start);let span=body.slice(start,end);if(segment.sourceEdits){assert.equal(hash(span),segment.candidateSHA256);for(const edit of segment.sourceEdits){assert.equal(span.split(edit.after).length-1,1);span=span.replace(edit.after,()=>edit.before);}}assert.equal(hash(span),segment.normalizedSourceSHA256);}
 for(const item of [...manifest.c1Revision.predecessorFiles,...manifest.captureRevision.predecessorFiles]){let body=older[item.file];for(const edit of item.sourceEdits.toReversed()){assert.equal(body.split(edit.after).length-1,1);body=body.replace(edit.after,()=>edit.before);}assert.equal(hash(body),item.previousSHA256);}
});
const namesFor=async runner=>{
 const begin=runner.indexOf('const variants = ['),end=runner.indexOf('const sceneMarkers =',begin), from=runner.indexOf('  await runFoundationsChecks('),to=runner.indexOf('\n} catch (error) { report.fatalError',from);assert.ok(begin>=0&&end>begin&&from>=0&&to>from);
 const api=['usePage','open','structure','sceneDelivery','stage','phase','geometry','screenshot','rootOf','panelOf','expect'],names=[];
 const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
 const registration=new AsyncFunction('check','runFoundationsChecks','runInferenceChecks','runTrainingChecks','runPretrainingChecks','runAlignmentChecks',...api,runner.slice(begin,end)+'\n'+runner.slice(from,to));
 await registration(async name=>names.push(name),f.runFoundationsChecks,i.runInferenceChecks,t.runTrainingChecks,p.runPretrainingChecks,a.runAlignmentChecks,...api.map(()=>undefined));return names;
};
let currentNames,newNames=[];
await group('Actual current 107 names match actual Git 91 with sole control inverse rename; 71 and 58 retained',async()=>{
 currentNames=await namesFor(sources['verify-public.mjs']);const actualPrior=await namesFor(git('verify-public.mjs'));await a.runAlignmentChecks({check:async name=>newNames.push(name)});
 assert.equal(currentNames.length,107);assert.equal(actualPrior.length,91);assert.equal(newNames.length,16);
 assert.deepEqual(proofs.restoreD1CaseNames(currentNames,newNames,d1),actualPrior);
 const preNames=[],trainNames=[];await p.runPretrainingChecks({check:async name=>preNames.push(name)});await t.runTrainingChecks({check:async name=>trainNames.push(name)});
 const seventyOne=actualPrior.filter(n=>!preNames.includes(n)),fiftyEight=seventyOne.filter(n=>!trainNames.includes(n));assert.deepEqual(seventyOne,c2.priorCaseNames);assert.deepEqual(fiftyEight,manifest.c1Revision.regressionBaseline.caseNames);
 report.caseCounts={current:107,added:16,previous:91,unchanged:90,c1:71,older:58};report.addedNames=newNames;
});
await group('Old-body, proof, and case-order mutations fail closed',()=>{
 for(const file of ['verify-public.mjs','pretraining-checks.mjs','predecessor-proof.mjs'])reject(()=>proofs.restoreC2ReleaseBodies({...sources,[file]:'// mutation\n'+sources[file]},d1));
 for(const mutate of [v=>{v.priorCaseNames[0]='changed'},v=>{v.controlMigration.priorIndex=88},v=>{v.controlMigration.newRoute='/docs/other'},v=>{v.predecessorFiles[1].previousSHA256='0'.repeat(64)},v=>{v.predecessorFiles[0].sourceEdits[0].after+=' missing'}]){const bad=structuredClone(d1);mutate(bad);reject(()=>proofs.restoreC2ReleaseBodies(sources,bad));}
 for(const mutate of [v=>v.reverse(),v=>{[v[0],v[1]]=[v[1],v[0]]},v=>{v[0]=d1.controlMigration.newName},v=>v.splice(65,1),v=>{v[v.indexOf(d1.controlMigration.newName)]=d1.controlMigration.oldName}]){const bad=[...currentNames];mutate(bad);reject(()=>proofs.restoreD1CaseNames(bad,newNames,d1));}
});
await group('Three public entrypoints require the same exact nine artifact routes; embeddings excluded',()=>{
 const expected=['/docs/llm-internals/inference-internals','/docs/llm-foundations/how-llms-generate-text','/docs/llm-foundations/tokenization','/docs/llm-internals/mixture-of-experts-internals','/docs/llm-internals/attention-variants-and-long-context','/docs/llm-internals/transformer-architecture','/docs/llm-foundations/llm-training-pipeline','/docs/llm-internals/pretraining-and-scaling-laws','/docs/llm-internals/alignment-theory'];
 for(const [file,re] of [['extract-ci-html.mjs',/const routes = \[\n([\s\S]*?)\n\]/],['collect-deployment.ps1',/\$expectedRoutes = @\(\n([\s\S]*?)\n\)/]]){const block=sources[file].match(re)[1], routes=[...block.matchAll(/'(\/docs\/[^']+)'/g)].map(x=>x[1]);assert.deepEqual(routes.toSorted(),expected.toSorted());assert.equal(new Set(routes).size,9);}
 assert.ok(sources['verify-public.mjs'].includes('const artifactRoutes = [alignmentPath, pretrainingPath, trainingPath, inferencePath, ...foundations.map(item => item.route), moePath, variantsPath, transformerPath]'));report.routes=expected;
});
await group('Independent oracle imports no product and fixed arithmetic uses literal distribution, not model outputs',()=>{
 assert.deepEqual([...sources['alignment-checks.mjs'].matchAll(/^import .* from '(.*?)'/gm)].map(x=>x[1]),['node:assert/strict']);
 assert.doesNotMatch(sources['alignment-checks.mjs'],/import\s*\(|website\/lib|preferenceFrame|dpoPairStatistics/);
 assert.deepEqual(a.ALIGNMENT_ORACLE.rows.map(({p,q,ratio})=>({p,q,ratio})),[{p:.5,q:.25,ratio:2},{p:.125,q:.25,ratio:.5}]);
 assert.equal(a.ALIGNMENT_ORACLE.explicit.probability,3/4);
 for(const beta of [.5,1,2]){const odds=Math.exp(beta*(Math.log(.5/.25)-Math.log(.125/.25)));const actual=a.ALIGNMENT_ORACLE.dpo[String(beta)];assert.ok(Math.abs(actual.probability-odds/(1+odds))<1e-12);assert.ok(Math.abs(actual.loss-Math.log1p(1/odds))<1e-12);assert.ok(Math.abs(actual.margin-Math.log(odds))<1e-12);}
});
const pair=(beta,stage=6)=>({stage,fullKL:'unknown',aggregation:'expectation',rows:[{id:'y-w',input:'x-0',p:.5,q:.25,ratio:2,logRatio:Math.log(2),weighted:beta*Math.log(2)},{id:'y-l',input:'x-0',p:.125,q:.25,ratio:.5,logRatio:-Math.log(2),weighted:-beta*Math.log(2)}],normalizers:[0,1].map(()=>({id:'z-x-0',input:'x-0',cancelled:String(stage===6)})),margin:Math.log(4**beta),probability:4**beta/(1+4**beta),loss:Math.log1p(1/4**beta)});
await group('DPO raw expectation rejects nonfinite observations, changed ratios, different x, fabricated KL, and aggregate conflation',()=>{
 for(const beta of [.5,1,2])for(const stage of [5,6])a.assertPreferenceObservation(pair(beta,stage),beta);
 for(const mutate of [v=>{v.rows[0].p=NaN},v=>{v.rows[0].q=0},v=>{v.rows[1].ratio=-1},v=>{v.rows[0].weighted=Infinity},v=>{v.rows[1].input='x-1'},v=>{v.normalizers[1].id='z-x-1'},v=>{v.normalizers[1].input='x-1'},v=>{v.normalizers[0].cancelled='false'},v=>{v.fullKL=.5},v=>{v.margin=NaN},v=>{v.probability=1},v=>{v.loss=0},v=>{v.aggregation='single-pair'}]){const bad=pair(1);mutate(bad);reject(()=>a.assertPreferenceObservation(bad,1));}
 for(const beta of [NaN,Infinity,0,-1,3])reject(()=>a.assertPreferenceObservation(pair(1),beta));
});
await group('Conceptual assertion negatives preserve proxy distinction and orthogonal source/granularity',()=>{
 const risk={stage:2,output:'answer-0',lanes:[{id:'proxy',value:'unknown'},{id:'quality',value:'unknown'}],guarantee:'false',constraint:'kl',reassessment:'true',suppressionGuarantee:'false'};a.assertRiskObservation(risk);
 for(const mutate of [v=>{v.lanes[1].id='proxy'},v=>{v.lanes[1].value=1},v=>{v.output='other'},v=>{v.suppressionGuarantee='true'}]){const bad=structuredClone(risk);mutate(bad);reject(()=>a.assertRiskObservation(bad));}
 const feedback={stage:2,harmlessness:'false',universality:'false',answer:'answer-0',axes:['source','granularity'],sources:['verifier','learned-reward-model'],granularities:['process','outcome'],relation:'orthogonal',caveat:'true'};a.assertFeedbackObservation(feedback);
 for(const mutate of [v=>{v.relation='same-axis'},v=>{v.sources=['process','outcome']},v=>{v.caveat='false'},v=>{v.harmlessness='true'}]){const bad=structuredClone(feedback);mutate(bad);reject(()=>a.assertFeedbackObservation(bad));}
});
await group('Local adapter rejects external URL/scheme/path, path traversal, and public evidence classes without browser launch',()=>{
 let launches=0;const opts={browser:{newContext(){launches++;throw Error('must not launch')}},expect:null,outputPath:()=>'',report:{evidenceClass:'localhost-static-export-browser'}};
 for(const baseURL of ['http://127.0.0.1:4209','http://localhost:4209','http://[::1]:4209'])l.createLocalAlignmentAdapter({...opts,baseURL});
 for(const baseURL of ['https://localhost:4209','http://localhost.example:4209','http://127.0.0.1.evil','http://localhost@evil.example','http://[::ffff:192.0.2.1]:4209','file:///C:/site','http://localhost:4209/ai-agent-library','https://pero3dev.github.io/ai-agent-library'])reject(()=>l.createLocalAlignmentAdapter({...opts,baseURL}));
 for(const basePath of ['/../foo','//evil','/a/b','/x?y','/x#z'])reject(()=>l.createLocalAlignmentAdapter({...opts,baseURL:'http://localhost:4209',basePath}));
 reject(()=>l.createLocalAlignmentAdapter({...opts,baseURL:'http://localhost:4209',report:{evidenceClass:'live-public-browser-and-http'}}));assert.equal(launches,0);
 assert.doesNotMatch(sources['local-alignment-adapter.mjs'],/deployed-sha|github-actions-pages-artifact|mergeSha\s*:|artifactEvidence\s*:/);
});
await group('Flat proof does not embed current manifest, self hash, or nested proof/manifest bodies',()=>{
 assert.deepEqual(Object.keys(d1),['schemaVersion','revision','predecessorManifestSHA256','priorCaseNames','priorCaseNamesSHA256','controlMigration','historicalFiles','predecessorFiles']);
 assert.ok(!sources['d1-predecessor-proof.json'].includes(hash(sources['source-mapping.json'])));assert.ok(!sources['d1-predecessor-proof.json'].includes(hash(sources['d1-predecessor-proof.json'])));
 assert.ok(!d1.historicalFiles.some(x=>['d1-predecessor-proof.json','source-mapping.json'].includes(x.file)));
});
report.status='passed';
} catch(error){report.status='failed';report.error={message:error.message,stack:error.stack};process.exitCode=1;}
report.finishedAt=new Date().toISOString();const out=path.join(process.env.TEMP,'alignment-d1-kit-independent-probes.json');fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,groups:report.groups.length,negativeProbes:report.negativeProbes,report:out,error:report.error},null,2));
