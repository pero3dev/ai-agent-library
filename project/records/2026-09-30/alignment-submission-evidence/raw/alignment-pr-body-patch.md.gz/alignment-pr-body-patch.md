## 変更内容

アラインメント理論の既存本文に、選好学習・代理報酬・フィードバックの3図15段階を追加します。読書位置と同期し、停止・手動送り・巻戻し・拡大に対応します。4数式とMermaidを保持し、本文は評価粒度と報酬の出所を区別する採択済み3か所のみ訂正します。

9記事107ケースの公開検査と別PCで辿れる検証記録を追加します。旧8記事の本文・図は維持し、図なし対照はembeddingsへ移します。CIの依存監査で検出されたbrace-expansionは、両lockfileの互換パッチ5.0.12へ更新します。

## 検証

- root check成功（484成功、実音声変換1skip）、サイト単体392成功、静的build 223 routes成功。
- Edge全体回帰333成功（音声fixture5skip）、WebKitの図解・数式42成功、最終selector交差Edge3成功。
- 独立した製品・kit・実画像168枚のレビュー。最終固定treeの記事独立レビューとharness policyを通過。
- 依存パッチ後のnpm ci・high監査・root check・静的再ビルドが成功。HTMLと配信資産の同一性、および両ブラウザーの9記事SPA遷移を独立した補足記録で確認。初回CIと補助検査の失敗原本も保持。

## 影響・残件

公開CI/Pages後、同じCI artifactの9記事HTMLと公開Edge/WebKit各107ケースを確認し、独立公開レビューを行います。物理端末・screen reader・物理印刷は未検証です。P1は公開済み8/15記事で、今回のD1公開受入後に次の記事へ進み、15記事完了時に停止します。

Agent: codex
Co-authored-by: Codex <codex@openai.com>
