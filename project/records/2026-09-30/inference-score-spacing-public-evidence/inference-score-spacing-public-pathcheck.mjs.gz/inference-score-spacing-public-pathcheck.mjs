import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const p=n=>path.join(process.env.TEMP,'inference-score-spacing-public-'+n),source=await readFile(p('support.mjs'),'utf8'),old=await readFile(p('support-v1-preserved.mjs'),'utf8'),a="assert.ok(!file.includes('..')&&!path.isAbsolute(file))",b="assert.ok(!file.split(/[\\\\/]/).includes('..')&&!path.isAbsolute(file))";
assert.equal(source,old.replace(a,b));const check=new Function('file','path','assert',b+'; return true'),tests=[];
for(const value of ['website/app/docs/[[...mdxPath]]/page.jsx','website/app/[[...mdxPath]]/page.jsx','docs/11-llm-internals/inference-internals.md']){assert.equal(check(value,path,assert),true);tests.push({value,accepted:true})}
for(const value of ['../secret','website/../secret','website/../../secret','website\\..\\secret','/outside/file','C:/outside/file','C:\\outside\\file','\\\\server\\share\\file']){assert.throws(()=>check(value,path,assert));tests.push({value,accepted:false})}
const sha=b=>createHash('sha256').update(b).digest('hex'),r={at:new Date().toISOString(),tests,passed:tests.length,failed:0,onlyPathGuardChanged:true,beforeSHA256:sha(old),afterSHA256:sha(source),publicHTTPRequests:0,browserLaunches:0};await writeFile(p('pathcheck.json'),JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));
