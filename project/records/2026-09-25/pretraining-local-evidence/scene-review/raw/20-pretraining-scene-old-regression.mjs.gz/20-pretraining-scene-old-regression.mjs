import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { gzipSync } from 'node:zlib'
import path from 'node:path'
import assert from 'node:assert/strict'
const repo='C:/dev/ai-agent-library', base='http://127.0.0.1:4208/ai-agent-library', output=path.join(process.env.TEMP,'pretraining-scene-supplemental')
await mkdir(output,{recursive:true})
const require=createRequire(path.join(repo,'website/package.json')), {chromium,expect:expectBase}=require('@playwright/test')
const expect=expectBase.configure({timeout:15000})
const registry=JSON.parse(await readFile(path.join(repo,'website/diagrams/registry.json'),'utf8'))
const sha=b=>createHash('sha256').update(b).digest('hex')
const report={kind:'independent-local-supplemental',startedAt:new Date().toISOString(),oldArticles:[],lazy:[],performance:[],screenshots:[],errors:[]}
const save=()=>writeFile(path.join(output,'result.json'),JSON.stringify(report,null,2)+'\n')
async function snapshot(){const a=JSON.parse(execFileSync(process.execPath,['website/scripts/diagram-acceptance.mjs'],{cwd:repo,encoding:'utf8',windowsHide:true}));const buildId=(await readFile(path.join(repo,'website/.next/BUILD_ID'),'utf8')).trim();const articles=[];for(const x of a.articles){const route='/docs/'+x.article.replace(/^docs\/\d+-/,'').replace(/\.md$/,'');const bytes=await readFile(path.join(repo,'website/out',route.slice(1)+'.html'));const response=await fetch(base+route),live=Buffer.from(await response.arrayBuffer());assert.equal(response.status,200);assert.equal(sha(live),sha(bytes));const ids=[...new Set([...bytes.toString('utf8').replaceAll('\\"','"').matchAll(/"b":"([A-Za-z0-9_-]+)"/g)].map(m=>m[1]))];assert.deepEqual(ids,[buildId]);articles.push({article:x.article,inputDigest:x.inputDigest,route,htmlSHA256:sha(bytes)})}assert.equal(articles.length,8);return{buildId,articles}}
report.before=await snapshot()
const browser=await chromium.launch({channel:'msedge',headless:true});report.browser={engine:'chromium',channel:'msedge',version:browser.version()}
const panel=(page,id)=>page.locator(`.reading-figure[data-diagram-id="${id}"] .aw-sticky > .aw-diagram`)
async function open(page,route){const response=await page.goto(base+route,{waitUntil:'networkidle'});assert.equal(response.status(),200);await page.waitForFunction(()=>[...document.querySelectorAll('.reading-figure')].every(n=>n.dataset.ready==='true'));await page.evaluate(()=>document.fonts.ready)}
async function stage(panel, figure, index) {
  const button = panel.getByRole('group', { name: '図解の段階', exact: true }).getByRole('button', { name: figure.labels[index], exact: true })
  if (index === 0) {
    // Scrolling to another figure can update its reading stage and move its controls.
    await button.evaluate(node => node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }))
    await expect.poll(() => button.evaluate(async node => {
      const sample = () => {
        const rect = node.getBoundingClientRect()
        return {
          stage: node.closest('.aw-diagram').dataset.stage,
          scrollY,
          x: rect.x, y: rect.y, width: rect.width, height: rect.height,
          inView: node.isConnected && rect.width > 0 && rect.height > 0 &&
            rect.top >= 0 && rect.bottom <= innerHeight && rect.left >= 0 && rect.right <= innerWidth
        }
      }
      const initial = sample()
      if (!initial.inView) return false
      const key = JSON.stringify(initial)
      for (let frame = 0; frame < 3; frame++) {
        await new Promise(resolve => requestAnimationFrame(resolve))
        if (JSON.stringify(sample()) !== key) return false
      }
      return true
    }), { intervals: [50, 100, 100] }).toBe(true)
  }
  await button.click(); await expect(button).toHaveAttribute('aria-pressed', 'true')
  await expect(panel).toHaveAttribute('data-stage', String(index))
  await expect(panel).toHaveAttribute('data-mode', 'manual')
  await expect(panel.getByRole('slider', { name: '図解の再生位置', exact: true })).toHaveValue(String(index))
}

async function seek(p,index){const labels=await p.getByRole('group',{name:'図解の段階',exact:true}).getByRole('button').allTextContents();await stage(p,{labels},index)}
async function capture(page,p,name){await p.scrollIntoViewIfNeeded();const f=path.join(output,name+'.png');await page.screenshot({path:f});report.screenshots.push({name,file:f,capture:'viewport'});const svg=p.locator('svg.aw-scene'),original=await page.evaluate(()=>({x:scrollX,y:scrollY}));try{await svg.evaluate(n=>scrollTo({top:scrollY+n.getBoundingClientRect().top-86,behavior:'instant'}));const b=await svg.boundingBox(), screen=await page.evaluate(()=>({h:innerHeight,w:innerWidth,dsf:devicePixelRatio}));assert.ok(b.y>=85&&b.y+b.height<=screen.h&&b.x>=0&&b.x+b.width<=screen.w);const clip={x:Math.floor(b.x),y:Math.floor(b.y),width:Math.ceil(b.x+b.width)-Math.floor(b.x),height:Math.ceil(b.y+b.height)-Math.floor(b.y)},file=path.join(output,name+'-scene.png');const png=await page.screenshot({path:file,clip});assert.equal(png.readUInt32BE(16),clip.width*screen.dsf);assert.equal(png.readUInt32BE(20),clip.height*screen.dsf);report.screenshots.push({name:name+'-scene',file,capture:'supplemental-full-scene',clip,deviceScaleFactor:screen.dsf,stylesModified:false})}finally{await page.evaluate(({x,y})=>scrollTo({left:x,top:y,behavior:'instant'}),original)}}
const markers=['PRETRAINING / LOSS & PERPLEXITY','PRETRAINING / SCALING LAWS','PRETRAINING / DATA','PRETRAINING / METRICS','PRETRAINING / COMPUTE BUDGET','TRAINING / STAGES','TRAINING / RUNTIME BOUNDARY','SELF-ATTENTION','TRANSFORMER / INPUT & OUTPUT','TRANSFORMER / POSITION','TRANSFORMER / BLOCK & WEIGHTS','ATTENTION / KV SHARING','ATTENTION VARIANTS / COMPUTE & MEMORY','ATTENTION / CONTEXT RANGE','MOE / ROUTING & LOAD','MoE / PARAMETERS & COMMUNICATION','GENERATION / TOKEN LOOP','TOKENIZATION / COUNTING','INFERENCE / SAMPLING','INFERENCE / CACHE & BATCHING','INFERENCE / SPECULATIVE DECODING','INFERENCE / QUANTIZATION']
try{
 for(const a of report.before.articles.filter(x=>!x.article.includes('pretraining-and'))){const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await open(page,a.route);const figures=[];for(const id of await page.locator('.reading-figure').evaluateAll(ns=>ns.map(n=>n.dataset.diagramId))){const p=panel(page,id),count=await p.getByRole('group',{name:'図解の段階',exact:true}).getByRole('button').count();for(let s=0;s<count;s++)await seek(p,s);await seek(p,Math.min(2,count-1));await capture(page,p,'old-'+id);figures.push({id,allIntegerStages:count,manualMode:true,representativeStage:Math.min(2,count-1)})}assert.deepEqual(errors,[]);report.oldArticles.push({article:a.article,figures,pageErrors:errors});await context.close();await save();console.log('old',a.article)}
}catch(error){report.errors.push({error:error.stack||String(error)});process.exitCode=1}finally{await browser.close();report.after=await snapshot();assert.deepEqual(report.before,report.after);report.identityUnchanged=true;report.finishedAt=new Date().toISOString();await save();console.log(JSON.stringify({output,oldArticles:report.oldArticles.length,lazy:report.lazy.length,performance:report.performance.length,errors:report.errors.length}))}