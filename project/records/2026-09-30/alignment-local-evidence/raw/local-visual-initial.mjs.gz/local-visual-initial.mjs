import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { readFile, stat, mkdir, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import path from 'node:path'
import { tmpdir } from 'node:os'
import { TRACKED_ARTICLES, getDiagramArticleAcceptance, getDiagramArticleConfig } from '../website/lib/diagram-article-acceptance.mjs'

// Supplemental local visual capture only. This never writes article acceptance gates.
const root = 'C:/dev/ai-agent-library', exportRoot = path.join(root, 'website/out')
const engine = process.argv[2] || 'chromium', port = engine === 'webkit' ? 4210 : 4209
assert.ok(['chromium', 'webkit'].includes(engine))
const base = `http://127.0.0.1:${port}/ai-agent-library`, route = '/docs/llm-internals/alignment-theory'
const output = path.join(tmpdir(), 'alignment-local-visual', `${engine}-${new Date().toISOString().replaceAll(':', '-')}`)
await mkdir(output, { recursive: true })
const sha = b => createHash('sha256').update(b).digest('hex')
const require = createRequire(path.join(root, 'website/package.json'))
const { chromium, webkit, expect } = require('@playwright/test')
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.png': 'image/png', '.txt': 'text/plain' }
const server = createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, base).pathname)
    if (!pathname.startsWith('/ai-agent-library/')) return response.writeHead(404).end()
    const candidate = path.resolve(exportRoot, pathname.slice('/ai-agent-library/'.length) || 'index.html')
    if (!candidate.startsWith(path.resolve(exportRoot) + path.sep)) return response.writeHead(403).end()
    for (const file of [candidate, `${candidate}.html`, path.join(candidate, 'index.html')]) {
      if (await stat(file).then(s => s.isFile(), () => false)) return response.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' }).end(await readFile(file))
    }
    response.writeHead(404).end()
  } catch { response.writeHead(500).end() }
})
await new Promise(resolve => server.listen(port, '127.0.0.1', resolve))
const report = { kind: 'author-local-supplemental-visual-capture', independent: false, startedAt: new Date().toISOString(), engine, screenshots: [], states: [], errors: [], pageErrors: [], consoleErrors: [] }
const save = () => writeFile(path.join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n')
async function identity() {
  const files = new Set(TRACKED_ARTICLES.flatMap(article => [article, ...getDiagramArticleConfig(article).inputFiles]))
  const hashes = {}
  for (const file of [...files].sort()) hashes[file] = sha(await readFile(path.join(root, file)))
  return { buildId: (await readFile(path.join(root, 'website/.next/BUILD_ID'), 'utf8')).trim(), htmlSHA256: sha(await readFile(path.join(exportRoot, route.slice(1) + '.html'))), articles: TRACKED_ARTICLES.map(article => ({ article, inputDigest: getDiagramArticleAcceptance({ article }).inputDigest })), files: hashes }
}
report.before = await identity()
const browser = await (engine === 'webkit' ? webkit : chromium).launch({ headless: true, ...(engine === 'chromium' ? { channel: 'msedge' } : {}) })
report.version = browser.version()
const figures = [['alignment-preference', 7], ['alignment-reward-risk', 3], ['alignment-feedback', 5]]
async function seek(panel, stage) {
  const button = panel.getByRole('group', { name: '図解の段階', exact: true }).getByRole('button').nth(stage)
  await button.scrollIntoViewIfNeeded()
  await expect.poll(() => button.evaluate(async node => {
    const sample = () => { const r = node.getBoundingClientRect(); return JSON.stringify([scrollY, node.closest('.aw-diagram').dataset.stage, r.x, r.y, r.width, r.height]) }
    const first = sample()
    for (let i = 0; i < 3; i++) { await new Promise(requestAnimationFrame); if (sample() !== first) return false }
    return true
  })).toBe(true)
  await button.click()
  await expect(panel).toHaveAttribute('data-stage', String(stage))
  await expect(panel).toHaveAttribute('data-mode', 'manual')
}
async function capture(page, panel, name) {
  const svg = panel.locator('svg.aw-scene')
  await svg.evaluate(node => scrollTo({ top: scrollY + node.getBoundingClientRect().top - 86, behavior: 'instant' }))
  const geometry = await svg.evaluate(node => {
    const v = node.viewBox.baseVal, r = node.getBoundingClientRect()
    const texts = [...node.querySelectorAll('text')].map(t => { const b = t.getBBox(); return { text: t.textContent, x: b.x, y: b.y, width: b.width, height: b.height } })
    const outside = texts.filter(b => b.x < -1 || b.y < -1 || b.x + b.width > v.width + 1 || b.y + b.height > v.height + 1)
    const intersections = []
    for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
      const a = texts[i], b = texts[j], x = Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x), y = Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y)
      if (x > 1 && y > 1) intersections.push({ a: a.text, b: b.text, x, y })
    }
    return { outside, intersections, texts, rect: { x: r.x, y: r.y, width: r.width, height: r.height }, viewport: { width: innerWidth, height: innerHeight, dsf: devicePixelRatio }, pageOverflow: document.documentElement.scrollWidth - innerWidth }
  })
  assert.deepEqual(geometry.outside, [], `${name}: outside scene`)
  assert.ok(geometry.pageOverflow <= 1, `${name}: page overflow`)
  const { rect: r, viewport: v } = geometry
  assert.ok(r.x >= 0 && r.y >= 85 && r.x + r.width <= v.width && r.y + r.height <= v.height, `${name}: capture bounds`)
  const clip = { x: Math.floor(r.x), y: Math.floor(r.y), width: Math.ceil(r.x + r.width) - Math.floor(r.x), height: Math.ceil(r.y + r.height) - Math.floor(r.y) }
  const file = path.join(output, `${name}-scene.png`), png = await page.screenshot({ path: file, clip })
  assert.equal(png.readUInt32BE(16), clip.width * v.dsf)
  assert.equal(png.readUInt32BE(20), clip.height * v.dsf)
  report.screenshots.push({ file, sha256: sha(png), capture: 'full-scene', stylesModified: false, clip, deviceScaleFactor: v.dsf })
  report.states.push({ name, geometry })
  await save()
}
try {
  for (const [width, height, theme] of [[1440, 1000, 'light'], [1280, 720, 'dark'], [390, 844, 'light']]) {
    const context = await browser.newContext({ viewport: { width, height }, reducedMotion: 'reduce' })
    await context.addInitScript(value => localStorage.setItem('theme', value), theme)
    const page = await context.newPage()
    page.on('pageerror', e => report.pageErrors.push(e.message))
    page.on('console', m => { if (m.type() === 'error') report.consoleErrors.push(m.text()) })
    const response = await page.goto(base + route, { waitUntil: 'networkidle' })
    assert.equal(response.status(), 200)
    assert.equal(sha(await response.body()), report.before.htmlSHA256)
    for (const [id] of figures) await expect(page.locator(`.reading-figure[data-diagram-id="${id}"]`)).toHaveAttribute('data-ready', 'true')
    await page.evaluate(() => document.fonts.ready)
    for (const [id, count] of figures) {
      const panel = page.locator(`.reading-figure[data-diagram-id="${id}"] .aw-sticky > .aw-diagram`)
      for (let stage = 0; stage < count; stage++) {
        await seek(panel, stage)
        await capture(page, panel, `${width}x${height}-${theme}-${id}-S${stage}`)
      }
      if (width === 1440 && id === 'alignment-preference') for (const beta of ['0.5', '2']) {
        await panel.getByRole('combobox', { name: '式中の β（説明用）', exact: true }).selectOption(beta)
        await capture(page, panel, `${width}x${height}-${theme}-${id}-S6-beta${beta}`)
      }
      if (width === 1440 && id === 'alignment-feedback') {
        await panel.getByRole('combobox', { name: '選好ラベルの作り手', exact: true }).selectOption('ai')
        await capture(page, panel, `${width}x${height}-${theme}-${id}-S4-ai`)
      }
    }
    await context.close()
  }
} catch (error) { report.errors.push(error.stack || String(error)); process.exitCode = 1 }
finally {
  await browser.close()
  await new Promise(resolve => server.close(resolve))
  report.after = await identity()
  report.identityUnchanged = JSON.stringify(report.before) === JSON.stringify(report.after)
  if (!report.identityUnchanged || report.pageErrors.length || report.errors.length) process.exitCode = 1
  report.finishedAt = new Date().toISOString()
  await save()
  console.log(JSON.stringify({ output, screenshots: report.screenshots.length, errors: report.errors, pageErrors: report.pageErrors, consoleErrors: report.consoleErrors, identityUnchanged: report.identityUnchanged }))
}
