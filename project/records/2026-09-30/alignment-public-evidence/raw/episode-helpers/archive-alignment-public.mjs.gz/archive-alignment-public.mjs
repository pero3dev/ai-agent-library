import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from 'node:fs'
import path from 'node:path'
import { gzipSync, gunzipSync } from 'node:zlib'

const repo = process.cwd(), temp = process.env.TEMP
const sourceRoot = path.join(temp, 'alignment-pr63-public-20260930')
const destination = path.join(repo, 'project/records/2026-09-30/alignment-public-evidence')
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const relative = file => path.relative(destination, file).replaceAll('\\', '/')
const artifactPath = path.join(sourceRoot, 'artifact-evidence.latest.json')
const artifact = JSON.parse(readFileSync(artifactPath, 'utf8'))
assert.equal(artifact.mergeSha, 'b6686c92dbb678ea8b94eb12df37a33207c4c84b')
assert.equal(artifact.runId, 36702086701)
assert.equal(artifact.artifactId, 11090349965)
assert.equal(artifact.expectedBuildId, 'Iytr-Mx-iwwzxrZ8pUUHR')
assert.equal(artifact.deploymentState, 'success')
assert.equal(artifact.documents.length, 9)
mkdirSync(destination, { recursive: true })
const selection = []
function add(file, storedName, kind) { selection.push({ file, storedName, kind }) }
function collect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    assert.ok(!entry.isSymbolicLink())
    const file = path.join(directory, entry.name)
    if (entry.isDirectory()) collect(file)
    else if (!entry.name.endsWith('.tar')) add(file, 'ci/' + path.relative(sourceRoot, file).replaceAll('\\', '/'), 'github-artifact-collection')
  }
}
collect(path.join(sourceRoot, 'ci-36702086701-attempt-1-20260930T104035054Z'))
add(artifactPath, 'artifact-evidence.latest.json', 'github-artifact-collection')
for (const name of [
  'alignment-pr63-before-merge.json', 'alignment-pr63-patch-checks.json',
  'alignment-pr63-actual-merge.json', 'alignment-pr63-actual-merge-message.txt',
  'alignment-pr63-patch-squash.txt', 'alignment-pr63-pr-build.log', 'alignment-pr63-pr-docs.log',
  'alignment-pr63-main-ci.json', 'alignment-pr63-main-build.log', 'alignment-pr63-main-docs.log', 'alignment-pr63-collector.log',
  'alignment-pr63-independent-input-proof.json', 'alignment-pr63-public-artifact-proof.json'
]) add(path.join(temp, name), name, 'submission-github-or-independent-input-proof')

// Final browser raws and actually viewed images are added only by an explicit
// selection after both complete runs and the independent public review exist.
const extraPath = path.join(repo, 'TEMP/alignment-public-final-selection.json')
let finalReview = null, finalSelection = null, finalLedger = null, validatedRuns = []
if (process.argv.includes('--final')) {
  const extra = JSON.parse(readFileSync(extraPath, 'utf8'))
  finalSelection = extra
  assert.equal(extra.mergeSha, artifact.mergeSha)
  finalReview = JSON.parse(readFileSync(extra.reviewJson, 'utf8'))
  assert.equal(finalReview.status, 'approved')
  assert.equal(finalReview.must.length, 0)
  assert.deepEqual(finalReview.release, {
    mergeSha: artifact.mergeSha, runId: artifact.runId,
    artifactId: artifact.artifactId, buildId: artifact.expectedBuildId
  })
  assert.ok(extra.files.some(item => path.resolve(item.file) === path.resolve(extra.reviewJson)))
  assert.ok(extra.files.some(item => path.resolve(item.file) === path.resolve(extra.viewedLedger)))
  finalLedger = JSON.parse(readFileSync(extra.viewedLedger, 'utf8'))
  assert.ok(Array.isArray(finalLedger) && finalLedger.length > 0)
  assert.equal(new Set(finalLedger.map(item => item.file)).size, finalLedger.length)
  for (const item of finalLedger) {
    assert.equal(item.actuallyViewed, true)
    assert.equal(sha(readFileSync(item.file)), item.sha256)
    assert.ok(extra.files.some(entry => path.resolve(entry.file) === path.resolve(item.file)))
  }
  assert.equal(extra.browserResults.length, 3)
  assert.equal(new Set(extra.browserResults.map(item => path.resolve(item.file))).size, 3)
  const repeatedCaseNames = ['pretraining: all 23 stages 1440x1000 light DSF1', 'public assets: HTTP 200, nonempty bodies and matching MIME types']
  assert.deepEqual(finalReview.repeatedCaseNames, repeatedCaseNames)
  assert.equal(finalReview.browserRuns.length, 3)
  const kinds = ['full-edge', 'full-webkit', 'focused-webkit']
  assert.deepEqual(extra.browserResults.map(item => item.kind), kinds)
  validatedRuns = extra.browserResults.map(({ label, file, kind }, i) => {
    const bytes = readFileSync(file), result = JSON.parse(bytes)
    const reviewed = finalReview.browserRuns.find(item => item.kind === kind)
    assert.equal(path.resolve(reviewed.file), path.resolve(file))
    assert.equal(reviewed.sha256, sha(bytes))
    assert.equal(result.expectedDeploymentSha, artifact.mergeSha)
    assert.equal(result.expectedBuildId, artifact.expectedBuildId)
    assert.deepEqual(result.artifactEvidence, artifact)
    assert.ok(result.finishedAt && !result.fatalError)
    assert.equal(result.expectedCaseCount, i === 2 ? 2 : 107)
    assert.equal(result.cases.length, i === 2 ? 2 : 107)
    assert.equal(new Set(result.cases.map(item => item.name)).size, result.cases.length)
    assert.equal(result.browser.engine, i === 0 ? 'chromium' : 'webkit')
    if (i === 0) assert.equal(result.browser.channel, 'msedge')
    assert.equal(result.status, i === 1 ? 'failed' : 'passed')
    assert.deepEqual(result.cases.filter(item => item.status !== 'passed').map(item => item.name), i === 1 ? [repeatedCaseNames[0]] : [])
    if (i === 2) assert.deepEqual(result.cases.map(item => item.name), repeatedCaseNames)
    assert.ok(extra.files.some(item => path.resolve(item.file) === path.resolve(file)))
    return { label, file, kind, result }
  })
  assert.deepEqual(validatedRuns[0].result.cases.map(item => item.name), validatedRuns[1].result.cases.map(item => item.name))
  assert.ok(Date.parse(validatedRuns[2].result.startedAt) > Math.max(...validatedRuns.slice(0, 2).map(item => Date.parse(item.result.finishedAt))))
  for (const entry of extra.files) add(entry.file, entry.storedName, entry.kind)
}
const files = [], storedPaths = new Set()
for (const { file, storedName, kind } of selection) {
  assert.ok(!path.isAbsolute(storedName) && !storedName.split(/[\\/]/).includes('..'))
  const bytes = readFileSync(file), isPNG = path.extname(file).toLowerCase() === '.png'
  const stored = path.join(destination, isPNG ? 'images' : 'raw', storedName + (isPNG ? '' : '.gz'))
  assert.ok(!storedPaths.has(stored), stored); storedPaths.add(stored)
  const packed = isPNG ? bytes : gzipSync(bytes, { level: 9 })
  mkdirSync(path.dirname(stored), { recursive: true })
  if (existsSync(stored)) assert.deepEqual(readFileSync(stored), packed, 'Never rewrite an archived original: ' + stored)
  else writeFileSync(stored, packed)
  const restored = isPNG ? readFileSync(stored) : gunzipSync(readFileSync(stored))
  assert.deepEqual(restored, bytes)
  files.push({ originalAbsolutePath: file, kind, originalBytes: bytes.length, originalSHA256: sha(bytes), storedPath: relative(stored), storedBytes: packed.length, storedSHA256: sha(packed), compression: isPNG ? 'none' : 'gzip', roundTripVerified: true })
}
for (const document of artifact.documents) {
  assert.equal(sha(readFileSync(document.localFile)), document.htmlSHA256)
  assert.ok(files.some(item => item.originalAbsolutePath === document.localFile))
}
const index = {
  schemaVersion: 1, kind: 'alignment-pr63-public-evidence-archive', savedAt: new Date().toISOString(),
  scope: finalReview ? 'Final public evidence; see independent review scope and actual image ledger.' : 'Preparation: actual GitHub release, CI artifact and independent input identity only. Browser and image acceptance are pending.',
  githubReleaseSucceeded: true, publicAccepted: Boolean(finalReview),
  mergeSha: artifact.mergeSha, runId: artifact.runId, artifactId: artifact.artifactId, buildId: artifact.expectedBuildId,
  sourceRoot, files,
  omitted: [{ kind: 'downloaded-artifact-tar', reason: 'The original CI artifact can be downloaded with the collector. Its tar hash, member inventory and selected nine original HTML documents are retained; the large tar is not committed.' }],
  references: { submission: '../alignment-submission-evidence/index.json', local: '../alignment-dependency-evidence/final-review.json', portableKit: '../../../../scripts/diagram-release/README.md' }
}
if (finalReview) {
  for (const [source, name] of [[finalSelection.reviewJson, 'final-review.json'], [finalSelection.viewedLedger, 'viewed-images.json']]) {
    const bytes = readFileSync(source), target = path.join(destination, name)
    if (existsSync(target)) assert.deepEqual(readFileSync(target), bytes)
    else writeFileSync(target, bytes)
  }
  index.finalReview = { file: 'final-review.json', sha256: sha(readFileSync(finalSelection.reviewJson)), checkedAt: finalReview.checkedAt }
  index.viewedImages = { file: 'viewed-images.json', sha256: sha(readFileSync(finalSelection.viewedLedger)), actuallyViewedUnique: finalLedger.length }
  const browserRows = validatedRuns.map(({ label, file, result }) => {
    const reference = files.find(item => path.resolve(item.originalAbsolutePath) === path.resolve(file))
    assert.ok(reference)
    return `| ${label} | ${result.cases.filter(item => item.status === 'passed').length}/${result.cases.length} | ${result.status} | [原本](${reference.storedPath}) |`
  })
  writeFileSync(path.join(destination, 'README.md'), `# アラインメント図解 PR #63 の公開証拠\n\n[独立公開レビュー](final-review.json)は${finalReview.checkedAt}にapproved・must 0。初回の機械検査と限定再実行を区別した合成受入であり、失敗した原本を書き換えない。公開受入の対象は同じ入力版の9記事。P1全15記事の完了ではない。\n\n| 実行 | 成功/実行 | 原status | 保存先 |\n| --- | --- | --- | --- |\n${browserRows.join('\n')}\n\n実視認は[台帳](viewed-images.json)の${finalLedger.length}枚（重複なし）。生成画像総数、既存承認からの限定継承、今回の実視認を区別する。原本内の旧絶対パス・failed・pendingは保持し、[索引](index.json)で相対保存先へ対応付ける。初回の操作待ちtimeoutの具体原因を、再実行の成功だけで確定しない。\n\n実mergeは\`${artifact.mergeSha}\`、main runは\`${artifact.runId}\`、Pages artifactは\`${artifact.artifactId}\`、BUILD_IDは\`${artifact.expectedBuildId}\`。9 HTMLのartifact同一性とactual mergeの入力照合を含む。巨大tarは保存せず、tar hash・member一覧・9原本HTMLと取得手順を保持する。\n\n[最終提出原本](../alignment-submission-evidence/README.md)、[ローカル補足](../alignment-dependency-evidence/final-review.json)、[制作・公開記録](../alignment-reading-diagrams.md)、[公開検証kit](../../../../scripts/diagram-release/README.md)へ接続する。保存helperは当時の保存作業専用で、新PCの再実行入口は公開kit。WebKitや画面幅の確認を物理iPhone Safariの受入と扱わない。\n`)
}
if (!finalReview) writeFileSync(path.join(destination, 'README.md'), `# アラインメント図解 PR #63 の公開証拠\n\n状態: 保存作業中。GitHubのmain CI・Pages成功、CI artifactの9記事HTML、独立入力照合を保存した。公開両ブラウザーと画像レビューは進行中で、公開受入は未完了。\n\n[索引](index.json)は元の絶対パス、相対保存先、原本と保存ファイルのSHA256、gzip復元一致を持つ。古い状態・pending・絶対パスは原本のまま保持し、元PCのパスを新PCの実行先として扱わない。\n\n実mergeは\`${artifact.mergeSha}\`、main runは\`${artifact.runId}\`、Pages artifactは\`${artifact.artifactId}\`、BUILD_IDは\`${artifact.expectedBuildId}\`。9 HTMLは同じartifactから選択して保存し、そのhashを確認した。巨大tarは保存せず、tar hash・member一覧・取得手順を保持する。\n\n[最終提出原本](../alignment-submission-evidence/README.md)、[ローカル補足レビュー](../alignment-dependency-evidence/final-review.json)、[公開検証kit](../../../../scripts/diagram-release/README.md)へ接続する。今回の公開画像の実視認と最終判定は、完了後に別原本を追補する。\n`)
// Commit acceptance only after every input and canonical file has been checked.
writeFileSync(path.join(destination, 'index.json'), JSON.stringify(index, null, 2) + '\n')
console.log(JSON.stringify({ files: files.length, originalBytes: files.reduce((n,f)=>n+f.originalBytes,0), storedBytes: files.reduce((n,f)=>n+f.storedBytes,0), publicAccepted: index.publicAccepted, indexSHA256: sha(readFileSync(path.join(destination, 'index.json'))) }))
