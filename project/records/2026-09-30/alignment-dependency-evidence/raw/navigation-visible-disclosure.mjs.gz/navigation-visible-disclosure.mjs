import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import path from 'node:path'
import { chromium, webkit, expect } from '../website/node_modules/@playwright/test/index.mjs'
import { getDiagramArticleAcceptance } from '../website/lib/diagram-article-acceptance.mjs'

const base = 'http://127.0.0.1:4183/ai-agent-library'
const output = path.join(process.env.TEMP, 'alignment-brace-patch', 'navigation-smoke-visible-disclosure')
assert.ok(!existsSync(output))
mkdirSync(output, { recursive: true })
const hash = data => createHash('sha256').update(data).digest('hex')
const articles = JSON.parse(readFileSync(path.join(process.env.TEMP,'alignment-independent-final-identity.json'),'utf8')).inputs.map(i => i.article)
const registry = JSON.parse(readFileSync('website/diagrams/registry.json','utf8'))
const fixtures = articles.map(article => ({ article, route: article.replace(/^docs\/\d\d-/, '/docs/').replace(/\.md$/,''), heading: readFileSync(article,'utf8').match(/^# (.+)$/m)[1], ids: registry.diagrams.filter(d => d.article === article && d.enabled).map(d => d.id) }))
const identity = () => ({ buildId: readFileSync('website/.next/BUILD_ID','utf8').trim(), inputs: articles.map(article => ({ article, inputDigest: getDiagramArticleAcceptance({article}).inputDigest })), html: fixtures.map(f => ({ route:f.route, sha256:hash(readFileSync('website/out'+f.route+'.html')) })) })
const server = spawn(process.execPath, ['scripts/serve-export.mjs'], {cwd:path.resolve('website'),env:{...process.env,NEXT_PUBLIC_BASE_PATH:'/ai-agent-library'},windowsHide:true,stdio:'ignore'})
const errors = []
try {
  for (let i=0;i<100;i++) { try { if ((await fetch(base+'/')).ok) break } catch {} await new Promise(r => setTimeout(r,100)); if(i===99) throw Error('server unavailable') }
  for (const engine of ['chromium','webkit']) {
    const result={engine,channel:engine==='chromium'?'msedge':null,startedAt:new Date().toISOString(),before:identity(),fixtures,navigations:[],responses:[],fontAndIcon:[],requestFailures:[],consoleErrors:[],pageErrors:[],cases:[],status:'running'}
    const pending=[]
    const browser=await (engine==='chromium'?chromium:webkit).launch(engine==='chromium'?{channel:'msedge'}:{})
    const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:'light',reducedMotion:'reduce'})
    const page=await context.newPage()
    page.on('console',m=>{if(m.type()==='error')result.consoleErrors.push(m.text())})
    page.on('pageerror',e=>result.pageErrors.push(String(e)))
    page.on('requestfailed',req=>result.requestFailures.push({url:req.url(),type:req.resourceType(),error:req.failure()?.errorText}))
    page.on('response',res=>{
      const req=res.request(),type=req.resourceType(),url=res.url(),mime=res.headers()['content-type']||''
      if(['document','fetch','script','stylesheet','font'].includes(type)||/favicon/.test(url)) result.responses.push({url,type,status:res.status(),mime,navigation:req.isNavigationRequest()})
      if(type==='font'||/favicon/.test(url))pending.push((async()=>{try{const body=await res.body();const rel=decodeURIComponent(new URL(url).pathname).replace(/^\/ai-agent-library\//,'');result.fontAndIcon.push({url,type,status:res.status(),mime,sha256:hash(body),outSHA256:hash(readFileSync(path.join('website/out',rel)))})}catch(e){result.fontAndIcon.push({url,type,error:String(e)})}})())
    })
    const clickRoute=async route=>{
      const category=route.split('/').slice(0,3).join('/')
      const disclosure=page.locator(`button[data-href="${category}"]:visible`).first()
      if(await disclosure.count() && await disclosure.isVisible()){
        const isOpen=await disclosure.evaluate(el=>el.closest('li')?.classList.contains('open'))
        if(!isOpen){await disclosure.click();await expect.poll(()=>disclosure.evaluate(el=>el.closest('li')?.classList.contains('open'))).toBe(true)}
      }
      const candidates=page.locator(`a[href="/ai-agent-library${route}"]`)
      let chosen
      for(const link of await candidates.all())if(await link.isVisible()){chosen=link;break}
      if(!chosen)return false
      const before=await page.evaluate(()=>performance.timeOrigin)
      await chosen.click()
      await expect(page).toHaveURL(base+route)
      const after=await page.evaluate(()=>performance.timeOrigin)
      assert.equal(after,before,'SPA transition must not reload document')
      result.navigations.push({route,timeOriginBefore:before,timeOriginAfter:after})
      return true
    }
    try {
      await page.goto(base+'/docs/llm-internals/interpretability-basics',{waitUntil:'networkidle'})
      for(const f of fixtures){
        if(!await clickRoute(f.route)){
          const category=f.route.split('/').slice(0,3).join('/')
          assert.ok(await clickRoute(category),`Visible category link missing ${category}`)
          assert.ok(await clickRoute(f.route),`Visible article link missing ${f.route}`)
        }
        await expect(page.locator('h1')).toHaveText(f.heading)
        await expect(page.locator('.reading-figure')).toHaveCount(f.ids.length)
        for(const id of f.ids){const fig=page.locator(`.reading-figure[data-diagram-id="${id}"]`);await fig.scrollIntoViewIfNeeded();await expect(fig).toHaveAttribute('data-ready','true')}
        const fig=page.locator(`.reading-figure[data-diagram-id="${f.ids[0]}"]`)
        await fig.scrollIntoViewIfNeeded()
        await fig.getByRole('button',{name:'本文に連動中',exact:true}).click()
        await expect(fig.locator('.aw-diagram')).toHaveAttribute('data-mode','manual')
        const slider=fig.getByRole('slider').first()
        await slider.focus();await slider.press('Home')
        await expect(slider).toHaveValue('0')
        await expect(fig).toHaveAttribute('data-current-stage','0')
        await fig.getByRole('button',{name:'次の段階',exact:true}).click()
        await expect(fig).toHaveAttribute('data-current-stage','1')
        await fig.getByRole('button',{name:'本文に連動する',exact:true}).click()
        await expect(fig.locator('.aw-diagram')).toHaveAttribute('data-mode','reading')
        await page.evaluate(()=>document.fonts.ready)
        result.cases.push({article:f.article,route:f.route,figures:f.ids,manualNextAndReadingReturn:true,status:'passed'})
      }
      await Promise.all(pending)
      result.after=identity();assert.deepEqual(result.after,result.before)
      assert.equal(result.consoleErrors.length,0);assert.equal(result.pageErrors.length,0)
      assert.ok(result.responses.every(r=>r.status<400),JSON.stringify(result.responses.filter(r=>r.status>=400)))
      const unexpected=result.requestFailures.filter(r=>!(['fetch'].includes(r.type)&&/ERR_ABORTED|cancelled/i.test(r.error)&&/\/ai-agent-library\/(docs\/|_next\/)/.test(r.url)))
      assert.equal(unexpected.length,0,JSON.stringify(unexpected))
      assert.ok(result.responses.some(r=>r.type==='fetch'&&/\.txt(?:\?|$)/.test(r.url)),'RSC requests observed')
      assert.ok(result.fontAndIcon.some(r=>r.type==='font'),'actual font requested')
      assert.ok(result.fontAndIcon.every(r=>!r.error&&r.sha256===r.outSHA256))
      result.status='passed'
    } catch(e){result.status='failed';result.error=e.stack;errors.push(engine+': '+e.message)}
    finally {result.finishedAt=new Date().toISOString();await Promise.allSettled(pending);writeFileSync(path.join(output,engine+'.json'),JSON.stringify(result,null,2)+'\n');await context.close();await browser.close()}
    console.log(JSON.stringify({engine,status:result.status,cases:result.cases.length,requests:result.responses.length,fontAndIcon:result.fontAndIcon.length,error:result.error}))
  }
} finally {server.kill()}
if(errors.length)throw Error(errors.join('\n'))
