import {readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
import assert from 'node:assert/strict'
import path from 'node:path'
import {getDiagramArticleConfig} from 'file:///C:/dev/ai-agent-library/website/lib/diagram-article-acceptance.mjs'
const repo='C:/dev/ai-agent-library',tmp=process.env.TEMP,require=createRequire(repo+'/website/package.json'),{unified}=require('unified'),parser=unified().use(require('remark-parse').default).use(require('remark-gfm').default).use(require('remark-math').default).use(require('remark-frontmatter').default,['yaml'])
const read=async f=>JSON.parse(await readFile(f,'utf8')),norm=v=>typeof v==='string'?v.replace(/\r\n?/g,'\n'):Array.isArray(v)?v.map(norm):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).filter(k=>k!=='position').sort().map(k=>[k,norm(v[k])])):v,sha=v=>'sha256:'+createHash('sha256').update(v).digest('hex')
const initial=await read(path.join(tmp,'pretraining-build-inputs-sep30-before.json')),final=await read(path.join(tmp,'pretraining-build-second-inputs-before.json')),article='docs/11-llm-internals/pretraining-and-scaling-laws.md',config=getDiagramArticleConfig(article),registry=await read(repo+'/website/diagrams/registry.json'),assignments=await read(repo+'/website/diagrams/articles.json'),tree=parser.parse(await readFile(path.join(repo,article),'utf8')),assignment=assignments.articles.find(a=>a.article===article),selected=config.primaryDiagramIds.map(id=>registry.diagrams.find(d=>d.id===id)),files={}
for(const file of [...config.inputFiles,...config.optionalInputs]){try{files[file]=sha(norm(await readFile(path.join(repo,file),'utf8')))}catch(e){if(e.code!=='ENOENT')throw e;files[file]=null}}
const digest=()=>sha(JSON.stringify(norm({article:tree,assignment,registry:selected,files})))
const currentDigest=digest();assert.equal(currentDigest,final.articles.find(a=>a.article===article).inputDigest)
const file='website/components/diagrams/pretraining-loss-perplexity-walkthrough.jsx',currentFileSHA256=files[file];files[file]=sha(norm(await readFile(path.join(tmp,'pretraining-loss-before-wire-fix.jsx'),'utf8')))
const reconstructedInitialDigest=digest();assert.equal(reconstructedInitialDigest,initial.articles.find(a=>a.article===article).inputDigest)
const unchanged=final.articles.filter(a=>a.article!==article).map(a=>{const i=initial.articles.find(x=>x.article===a.article);assert.equal(i.inputDigest,a.inputDigest);return{article:a.article,inputDigest:a.inputDigest}})
const proof={checkedAt:new Date().toISOString(),meaning:'Current complete C2 normalized input bundle exactly reproduces original pre-run digest by replacing only the loss JSX hash with independently saved pre-fix bytes; all other bundled article/registry/assignment/source inputs are thus unchanged. Other seven article input digests are identical.',inputFiles:config.inputFiles.length+config.optionalInputs.length,replacedFile:file,currentFileSHA256,initialFileSHA256:files[file],currentDigest,reconstructedInitialDigest,otherSevenUnchanged:unchanged}
await writeFile(path.join(tmp,'pretraining-entire-input-delta-proof.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof,null,2))
