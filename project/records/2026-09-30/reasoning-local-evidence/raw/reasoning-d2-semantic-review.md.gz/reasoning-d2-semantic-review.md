# D2 semantic review

判定: approved / low、must 0 / should 1。実判定時刻 2026-09-30T11:42:46.554Z、記録時刻 2026-09-30T11:50:52.156Z。Reviewer: 01a0ced7-e41c-70c1-904e-2ae30ff2fa4b:/root/inference_doc_review。

2 model / 2 scene / 2 CSS / 2 modeltestsとshared AST・MDX安全性・受入統合・CI timeoutの独立した読み取りレビュー。実画面・kit・正式記事公開・CI/public受入は範囲外です。根拠と確認対象hashは[JSON](reasoning-d2-semantic-review.json)に固定しました。

| 重要度 | ファイル・行 | 指摘 | 修正案 |
| --- | --- | --- | --- |
| should | website/components/diagrams/reasoning-sequence-walkthrough.jsx:62 | 「CoT 指示を加えるだけではない」は原文より断定的 | 「CoT 指示だけとは限らない」。11:42判定時は未反映 |

その他7製品ファイルとshared統合は問題なし。43 ASTノード・9 H3・18 body、包装6 H3・14 body、43論点（動的26/静的17）。元AST復元とMDX再解析、採択literalを使う独立モデル照合（sequence境界12点、evaluation全30設定段階）を確認。未操作READ0→2→3と逆順、固定重み、思考非再現、費用null、元表と同一入力比較の分離、段階限定focus/対象外null、境界内探索、4空試行12未計測欄に問題なし。S1/S2回答未展開枠は許容できる最小可視集合への追加です。

旧27 registry項目・9記事割当、literal MDX許可、依存digestとreview/local/public別ゲートを保持。CIはbuild timeout20→30分のみ。作者18単体試験・root build/受入43成功は報告として区別します。実画面は未確認です。

## 保存時の追補

2026-09-30T11:50:52.156Z、保存中にsceneが修正済みになったことを確認しました。現SHA 9dc1f67e63e1a579e3e8d6df869916a9fb22fec8151d9bce35798843b9a8a19c。上記1語句を逆置換すると実判定版77271156f7553e4110c5ed79a75a65aa50bf27f74414396ceb1e0093d677a868へraw hash一致。他7製品ファイルは不変。原判定は保持し、shouldはソース上解消、修正後buildと画面確認は未実施として記録します。shared差分は保存前に再読しました。
