# D2 reasoning 公開 kit 拡張の準備案

作成日: 2026-09-30。作者: /root/inference_change_evidence。
状態: 計画案。独立レビュー、実装、ローカル検証、公開受入は未実施。
この作業の書込みは OS TEMP の本書と [詳細 JSON](reasoning-d2-kit-plan-20260930.json) のみ。

## 件数と対象

現行 D1 の 107 ケース・9 記事を保持し、D2 に 14 ケースと 1 記事を追加する。合計は 121 ケース・10 記事。
対象は /docs/llm-foundations/reasoning-models。2 図・9 段階・8 READ を採択案どおり扱う。
reasoning-sequence は 4 段階、READ は 0/2/3、段階 1 は手動操作で到達する。
reasoning-evaluation は 5 段階すべてが READ に対応する。本文・AST・見出し・表・数式を変更しない。
P1 の採択済み 15/199 記事の公開受入後に停止する。P0 部分対応 2 記事を混ぜず、P2 へ進まない。

| 新規ケース | 数 | 必須の観測 |
| --- | ---: | --- |
| 6 profiles の全段階 | 6 | 各 profile で両図の全 9 段階、54 状態。可視意味・geometry・通常 viewport と全図を記録 |
| sequence 意味 oracle | 1 | 履歴のない各段階、中点前/中点/中点後と逆 seek、固定 node/edge、未測定・非再現の意味 |
| evaluation 意味 oracle | 1 | 3 × 2 設定の全 5 段階、計 30 観測。段階限定操作と対象外の無効化 |
| keyboard/modal | 1 | 2 controls / 5 options、対象段階内外、フォーカス復帰、図間・inline/modal の状態分離 |
| READ | 1 | 全 8 停止点、段階 1 を未操作でも READ 2 に必要な意味が残ること、図間状態分離 |
| native clock | 2 | 図ごとの実経過再生、停止時固定、巻戻し・再生し直し・終端。時計の偽装なし |
| noJS / print | 2 | 原文と全 9 静的段階説明。印刷時の操作 UI 非表示と整合した静止図 |

Profiles は 1440×1000 light/dark、1280×720 light、390×844 light/dark（以上 DSF 1）、960×540 light（DSF 2）。
生成画像と独立担当が実際に視認した画像は分けて記録する。

## 独立 fixture と意味

製品の frame/model/registry を期待値の計算に用いず、承認済み本文と設計の literal を JSON と検査モジュールに固定する。
可視 DOM/SVG から観測値を作り、独立 validator と 1 フィールドずつ壊した負例で検査する。隠れた属性だけでは合格にしない。

- sequence: prior-symbols → next-prediction の条件付けを READ 0 と READ 2 で可視化。READ 2 は別枠の学習、実行時重み固定、実際の内的思考ではない説明も同時に残す。資源帯は推論/最終回答の模式区分で、token 数・時間・価格・費用式は null。
- evaluation: 元の表の 3 行と左右の候補は異なるタスク例。同一入力・モデル・指示・評価基準の比較枠とは混同しない。quality/cost/latency は未測定、value/unit は null。自動採否・勝者・性能曲線を作らない。
- taskFocus は 3 値で段階 0 のみ。effortFocus は 2 値で段階 1/2 のみ。対象外は selector 不在かつ effective focus null（DOM は none）。保存された設定があっても他段階の意味を変えない。
- evaluation 段階 3 は目標・制約・承認・根拠確認・業務規程と outside-model 実行境界。段階 4 は lower/higher 各 2 の模式試行、同じ入力と設定ごとの同じ条件、4 × 3 の未測定 12 セル。A/B は推奨サンプル数ではない。
- 全段階への直接到達と前後方向の中間 phase を検査し、直前の操作や履歴がなくても意味が成立することを確認する。

noJS は元の 9 H3・2 tables・11 lists・1 blockquote・リンク・本文と全 9 段階説明を保持する。
本文全 AST の一致（43 root nodes、18 body）は root 担当の統合試験で扱う。READ 8 を理由に手動段階 1 の説明を欠かさない。

## 変更するファイル

新規 4 ファイルは reasoning-checks.mjs、local-reasoning-adapter.mjs、d2-predecessor-proof.json（以上 scripts/diagram-release）、website/tests/browser/reasoning.spec.mjs。
更新する kit は verify-public.mjs、collect-deployment.ps1、extract-ci-html.mjs、check-preparation.mjs、predecessor-proof.mjs、local-alignment-adapter.mjs、source-mapping.json、README.md。
必要な負例は tests/unit/diagram-release-portable.test.mjs に追加する。製品・AST 試験は root の担当。
既存 alignment-checks.mjs と alignment.spec.mjs、他の既存検査モジュールは不変とする。

ローカルは既存 local-alignment-adapter の factory に extraSceneMarkers=[] を加える最小案。
文字列配列を検証して marker 集合へ追補し、既定動作・network/geometry/capture 条件を保つ。
新しい薄い local-reasoning-adapter が同じ API と 14 個の実際の公開検査 callback を使う。
旧 9 記事の scene 分離判定にも D2 marker を加える。localhost へ偽の公開 SHA/artifact を渡さず、TEMP や絶対 import に依存しない。

表示 marker の REASONING / SEQUENCE と REASONING / EVALUATION は今回の提案であり、承認済み interface の既定値ではない。
製品担当と計画レビューで確認した後に固定する。隠れたテスト専用 marker は作らない。

## 旧 107 ケースと source-map の保護

現行 manifest は 40cca5a2f969f4c0385fac358cf4988decb6f72076c5b91e1b52fe22153adee9。
実登録から列挙した旧 107 名称の順序 hash は 738970b0cf992440fd36d40e5445c44b71f988185e6dcbf4c4422313c39fe589。
列挙は callback 本体を実行していない。旧 mandatory favicon は index 81 にあり、その直前に新 14 ケースを置く。
旧名称・順序・検査本文・helper 条件を弱めず、embeddings の無図対照と D1 の過去の対照移行証拠を保持する。

1. 編集前に現行 18 ファイル・manifest・登録 107 名称を凍結し、今回の hash と照合する。変化があれば明示的に baseline を更新する。
2. collector/extractor/public runner の 10 番目へ reasoning route を追加する。CI run/attempt/head、10 HTML の単一 BUILD、regular file、欠落・重複・mixed build の拒否を保つ。
3. flat な D2 proof に prior manifest/hash/107 名称/18 file hash と固定 4 ファイルの逆置換を保存する。4 ファイルは 3 entrypoint と local-alignment-adapter。現在 manifest や proof 自身の hash を持たせない。
4. predecessor-proof は既存 prefix を保護して復元関数を追記する。D2 → D1 → C2 → C1 の元 bytes と、121 → 107 → 91 → 71 → 58 の名称・順序を復元検査する。
5. preparation に 10 routes / 121 cases / 14 new / 2 figures / 9 stages / 8 READ / 1 manual / 6 profiles / 2 controls / 5 options / 30 grid と新 spec allowlist を追加する。旧 assertion の改変、削除・並替え・重複、逆置換 0/複数一致等を負例にする。
6. inventory は 18 + 4 = 22。既存 sourceRawSHA256/normalizedSourceSHA256/歴史 revision を保持し、最終 bytes の portableSHA256 を同期する。d2Revision は新規内容と未承認状態を記録し、原記録を書換えない。
7. syntax・portable unit・offline preparation の後、root の build と両 engine のローカル 14 ケース、独立コード/視認レビューを実施する。CI/Pages 成功後に初めて 10 HTML と両公開 engine の 121 ケースを収録し、現行入力へ結合する。

HTTP/MIME/BUILD/artifact/script/style/font/console 条件と noJS の CSP 限定例外は維持する。
依存 patch の補足 SPA レビューは公開 kit の network 条件を緩める根拠にしない。

## 残る判断

本案の独立レビューと表示 marker の確認が残る。D2 の実装開始、試験成功、CI/公開受入を意味しない。
詳細 JSON は全 107 名称、14 追加名称、literal fixtures、現行根拠 hash、変更範囲と未実施事項を保存する。
