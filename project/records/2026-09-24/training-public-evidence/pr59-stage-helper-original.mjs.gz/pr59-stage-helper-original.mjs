async function stage(panel, figure, index) {
  const button = panel.getByRole('group', { name: '図解の段階', exact: true }).getByRole('button', { name: figure.labels[index], exact: true })
  await button.click(); await expect(button).toHaveAttribute('aria-pressed', 'true')
  await expect(panel).toHaveAttribute('data-stage', String(index))
  await expect(panel).toHaveAttribute('data-mode', 'manual')
  await expect(panel.getByRole('slider', { name: '図解の再生位置', exact: true })).toHaveValue(String(index))
}
