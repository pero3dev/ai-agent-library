# D1 initial independent code and scene review

Checked 2026-09-29T20:19:38.924Z; reviewer /root/pretraining_visual_review. **approved / low; must 0, should 0** for the scope below. Complete local and public gates remain pending.

- Independent code/formula/integration proof: 14 groups passed. DPO expected values use odds 4^β independently of production arithmetic; A1–A3 plus date-only article delta; 42 topics (27 dynamic / 15 static); all 15 READ stages; original four equations and Mermaid; all eight enabled subsets preserve the full AST.
- Actually viewed **96 full-scene PNGs**: Edge 48, WebKit 48. All 15 stages at 1440×1000 light, 1280×720 dark, 390×844 light, plus β=.5/2 and AI selection per engine. No viewport or modal image is included. Initial generated count is also 96; equality follows actual inspection, not an assumption.
- All initial bbox candidates were checked against their actual image; glyphs remain separate. No visible clipping, overlap or semantic omission found in these captures. Narrow text scales down, so enlargement/control acceptance remains required.
- Initial capture console 404 events are retained. Root diagnosed its supplementary server base URL handling; these raw runs are not clean-network acceptance.
- Build XJR9sUrJP0VbXQCKQiQ8F; both capture identities and all nine input digests equal the independent proof.
- Old eight article/source inputs outside the five additive shared integration files are unchanged from 5940334a6fd3aab8178cfeb8746a58c8b937d390; existing registry and assignment objects are unchanged. Carry is limited to earlier accepted scene semantics, with current runtime regression still pending.

The [DPO paper](https://arxiv.org/html/2305.18290) supports the reward parameterization and same-input cancellation; [Let's Verify Step by Step](https://arxiv.org/html/2305.20050v1) supports distinguishing supervision granularity from how reward labels are obtained.

Raw proof: C:\Users\81906\AppData\Local\Temp\alignment-independent-code-proof.json

Actual image ledger: C:\Users\81906\AppData\Local\Temp\alignment-independent-initial-viewed-images.json

Structured review: C:\Users\81906\AppData\Local\Temp\alignment-independent-initial-review.json

Pending: full current browser/kit results, normal viewport and READ/modal/playback/no-JS/print images, low-PC DSF2/dark narrow conditions, runtime and performance regression, formal frozen-tree review, public D1 acceptance. Physical devices and real screenreader are untested.
