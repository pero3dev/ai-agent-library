# D1 PR63 独立公開レビュー

- 判定: **approved / low**。must 0、should 0。
- 確認日時: 2026-09-30T11:18:33.154Z
- 公開: merge b6686c92dbb678ea8b94eb12df37a33207c4c84b / CI 36702086701 / artifact 11090349965 / BUILD Iytr-Mx-iwwzxrZ8pUUHR

Edge 原本は107/107。WebKit 原本は106/107で、PPLクリックの15秒タイムアウト1件を失敗のまま保持する。同じ公開成果物・操作・検証条件で当該23段階ケースとassetケースを1回だけ再実行し2/2成功。全WebKit再走や原因解明を意味しない。原失敗＋限定補完で合成受入とする。

CI tarに対し、公開9記事HTMLとBUILD、Edge/WebKit各75asset、限定52asset、観測resource4650/4658/52を独立に照合。実mergeの137入力fileは前後一致、9入力digestは承認済み依存補足と一致。詳細と各記事の最初/最後のHTML観測はfinal-identityに記録。

今回の実視認は**137枚**（Edge 66 / WebKit 71、全scene 92 / viewport 45）。生成1777枚とは別。D1両engine全15段階、β両端・AI、6profile代表、modal/noJS/print、旧8代表、再試験PPL/比較条件を確認。初回失敗直前2枚も台帳に含む。文字衝突・見切れ・意味上のmustなし。D1 bbox候補104観測/engineは独立localとpair/wire差分0。PUBLIC-V1の6桁負号表示も両engineで分離を確認。

旧8はPR62公開承認、D1共有追加の独立local確認、依存patch補足、現在の公開回帰/代表画像の範囲で継承する。旧8全inputDigest不変や全画像再視認とは主張しない。以前の47/90/168枚は今回枚数に含めない。

成果物:
- C:/Users/81906/AppData/Local/Temp/alignment-pr63-public-final-review.json
- C:/Users/81906/AppData/Local/Temp/alignment-pr63-public-final-viewed-images.json
- C:/Users/81906/AppData/Local/Temp/alignment-pr63-public-final-identity.json

実機iPhone/Safari・実スクリーンリーダー・物理印刷・新しい公開性能測定は未実施。原rawのpending/failedを改変せず、この独立判定を別bindingする。
