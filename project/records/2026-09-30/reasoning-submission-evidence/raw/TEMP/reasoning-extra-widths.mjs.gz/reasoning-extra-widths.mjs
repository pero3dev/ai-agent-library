import fs from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { reasoningProfiles, runReasoningChecks } from '../scripts/diagram-release/reasoning-checks.mjs'
import { createLocalReasoningAdapter } from '../scripts/diagram-release/local-reasoning-adapter.mjs'
import { TRACKED_ARTICLES, getDiagramArticleAcceptance } from '../website/lib/diagram-article-acceptance.mjs'

// Local supplement only. Adds two viewport registrations in this process and
// executes their unchanged profile callbacks. No source/kit/HTML/DOM edits.
const repo = process.cwd(), sha = b => createHash('sha256').update(b).digest('hex')
const require = createRequire(path.join(repo, 'website/package.json'))
const { chromium, webkit, expect } = require('@playwright/test')
const root = path.join(os.tmpdir(), 'reasoning-extra-widths', new Date().toISOString().replaceAll(':', '-'))
await fs.mkdir(root, { recursive: true })
const extra = [[1920,1080,'light',1],[768,1024,'light',1]]
assert.equal(reasoningProfiles.length, 6)
reasoningProfiles.push(...extra)
const names = extra.map(([w,h,t,d]) => `reasoning: all 9 stages ${w}x${h} ${t} DSF${d}`)
const identity = async () => ({
  buildId: (await fs.readFile('website/.next/BUILD_ID', 'utf8')).trim(),
  htmlSHA256: sha(await fs.readFile('website/out/docs/llm-foundations/reasoning-models.html')),
  inputs: TRACKED_ARTICLES.map(article => ({ article, inputDigest: getDiagramArticleAcceptance({ article }).inputDigest }))
})
const result = { evidenceClass: 'supplemental-local-widths', startedAt: new Date().toISOString(), publicAuditExecuted: false, nativeZoomTested: false, sourceSHA256: sha(await fs.readFile('scripts/diagram-release/reasoning-checks.mjs')), before: await identity(), cases: [] }
const save = () => fs.writeFile(path.join(root, 'result.json'), JSON.stringify(result, null, 2) + '\n')
try {
  for (const engine of ['edge', 'webkit']) {
    const browser = await (engine === 'edge' ? chromium.launch({ channel: 'msedge', headless: true }) : webkit.launch({ headless: true }))
    try {
      for (let i = 0; i < names.length; i++) {
        const directory = path.join(root, `${engine}-${extra[i][0]}`)
        await fs.mkdir(directory)
        const report = { evidenceClass: 'localhost-static-export-browser', publicAuditExecuted: false, independentVisualReview: 'pending-actual-images', screenshots: [] }
        const entry = { name: names[i], engine, browserVersion: browser.version(), status: 'running' }
        const api = createLocalReasoningAdapter({ browser, expect: expect.configure({ timeout: 15000 }), baseURL: 'http://127.0.0.1:4183', basePath: '/ai-agent-library', outputPath: n => path.join(directory, n), report })
        let executed = 0
        try {
          await runReasoningChecks({ ...api, check: async (name, operation) => { if (name === entry.name) { executed++; await operation(entry) } } })
          assert.equal(executed, 1)
          entry.status = 'passed'
        } catch (error) { entry.status = 'failed'; entry.error = error.stack; throw error }
        finally {
          const file = path.join(directory, 'reasoning-result.json')
          await fs.writeFile(file, JSON.stringify({ ...report, result: entry }, null, 2) + '\n')
          result.cases.push({ file, sha256: sha(await fs.readFile(file)), engine, name: entry.name, status: entry.status, imagesGenerated: report.screenshots.length })
          await save()
        }
      }
    } finally { await browser.close() }
  }
  assert.equal(result.cases.length, 4)
  result.after = await identity()
  assert.deepEqual(result.before, result.after)
  result.status = 'passed'
} catch (error) { result.status = 'failed'; result.error = error.stack; process.exitCode = 1 }
finally { result.finishedAt = new Date().toISOString(); await save(); console.log(JSON.stringify({ root, status: result.status, cases: result.cases })) }
