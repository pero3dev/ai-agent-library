import { fileURLToPath } from 'node:url'
import base from '../website/playwright.config.mjs'
// Same tests, workers, assertions and browser configuration. A root-owned static
// server serves one immutable build to separate engine runs and output folders.
export default { ...base, testDir: fileURLToPath(new URL('../website/tests/browser/', import.meta.url)), webServer: undefined }
