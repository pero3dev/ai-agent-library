import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'

assert.ok(['--dry-run', '--c2-public-accepted'].includes(process.argv[2]), 'Apply only after independent C2 public acceptance')
const dryRun = process.argv[2] === '--dry-run'
const root = 'C:/dev/ai-agent-library'
const prep = JSON.parse(readFileSync(path.join(tmpdir(), 'alignment-d1-readonly-preparation-20260930.json'), 'utf8'))
const pending = new Map()
const read = file => (pending.get(file) ?? readFileSync(path.join(root, file), 'utf8')).replace(/\r\n/g, '\n')
const write = (file, value) => pending.set(file, value)
const once = (source, before, after) => {
  assert.equal(source.split(before).length, 2, `Expected one occurrence: ${before}`)
  return source.replace(before, after)
}
const edit = (file, fn) => write(file, fn(read(file)))
const json = value => JSON.stringify(value, null, 2)
const pick = (object, keys) => Object.fromEntries(keys.map(key => [key, object[key]]))
const ids = prep.diagrams.map(d => d.id)
const article = prep.article.file
const original = read(article)
assert.equal(createHash('sha256').update(original).digest('hex'), prep.article.sourceSHA256)
let corrected = original
for (const c of prep.corrections) corrected = once(corrected, c.old, c.replacement)
assert.equal(createHash('sha256').update(corrected).digest('hex'), prep.article.correctionOnlyCandidateSHA256)
corrected = once(corrected, 'last_updated: "2026-07-09"', 'last_updated: "2026-09-30"')
// Only the two references actually re-read are marked as re-accessed.
corrected = once(corrected, 'DPO の原論文(Rafailov et al., 2023、アクセス日: 2026-07-09)', 'DPO の原論文(Rafailov et al., 2023、アクセス日: 2026-09-30)')
corrected = once(corrected, 'プロセス報酬(Lightman et al., 2023、アクセス日: 2026-07-09)', 'プロセス報酬(Lightman et al., 2023、アクセス日: 2026-09-30)')
write(article, corrected)

edit('website/lib/diagram-registry.mjs', source => once(source, 'const BINDINGS = {', 'const BINDINGS = {\n' + prep.diagrams.map(d => `  '${d.id}': ${json(pick(d, ['article', 'route', 'binding', 'stageCount', 'headings', 'sourceHeadings', 'blockGroups', 'blockTypes']))},`).join('\n')))
edit('website/diagrams/registry.json', source => {
  const registry = JSON.parse(source)
  for (const d of prep.diagrams) {
    assert.ok(!registry.diagrams.some(entry => entry.id === d.id))
    registry.diagrams.push({ ...pick(d, ['id','article','route','binding','stageCount','headings','sourceHeadings','blockGroups']), sourceDigest: d.postCorrectionSourceDigestCandidate, reviewedDigest: d.postCorrectionSourceDigestCandidate, enabled: true, status: 'reviewed', articleCoverage: 'pending' })
  }
  return json(registry) + '\n'
})
edit('website/lib/diagram-decoration.mjs', source => {
  source = once(source, 'const components = {', 'const components = {\n' + ids.map(id => `  '${id}': 'AlignmentWalkthrough',`).join('\n'))
  return once(source, "'TrainingWalkthrough', 'PretrainingWalkthrough'].includes", "'TrainingWalkthrough', 'PretrainingWalkthrough', 'AlignmentWalkthrough'].includes")
})
edit('website/lib/mdx-safety.mjs', source => {
  source = once(source, 'const readingStages = {', 'const readingStages = {\n' + prep.diagrams.map(d => `  '${d.id}': ${d.stageCount},`).join('\n'))
  source = once(source, "'TrainingWalkthrough', 'PretrainingWalkthrough'])", "'TrainingWalkthrough', 'PretrainingWalkthrough', 'AlignmentWalkthrough'])")
  source = once(source, "PretrainingWalkthrough: 'diagramId', ReadingStep", "PretrainingWalkthrough: 'diagramId', AlignmentWalkthrough: 'diagramId', ReadingStep")
  return once(source, 'const attributes = {', `const attributes = {\n  AlignmentWalkthrough: { diagramId: value => ${json(ids)}.includes(value) },`)
})
edit('website/mdx-components.js', source => {
  source = once(source, "import { PretrainingWalkthrough }", "import { AlignmentWalkthrough } from './components/diagrams/alignment-walkthrough'\nimport { PretrainingWalkthrough }")
  return once(source, '  PretrainingWalkthrough,', '  PretrainingWalkthrough,\n  AlignmentWalkthrough,')
})
const dispatcher = 'website/components/diagrams/alignment-walkthrough.jsx'
assert.ok(!existsSync(path.join(root, dispatcher)))
write(dispatcher, `'use client'\n\nimport { lazy } from 'react'\nimport { DiagramBoundary } from './diagram-boundary'\nimport { ReadingArticleContents } from './reading-article-navigation'\n${ids.map(id => `import './${id}.css'`).join('\n')}\n\nconst scenes = {\n${ids.map((id, i) => `  '${id}': lazy(() => import('./${id}-walkthrough').then(module => ({ default: module.${['AlignmentPreference','AlignmentRewardRisk','AlignmentFeedback'][i]} })))`).join(',\n')}\n}\n\nexport function AlignmentWalkthrough({ diagramId, children }) {\n  const Scene = Object.hasOwn(scenes, diagramId) ? scenes[diagramId] : null\n  if (!Scene) return <>{children}</>\n  return <><ReadingArticleContents diagramId={diagramId} /><DiagramBoundary key={diagramId} fallback={children}>\n    <Scene>{children}</Scene>\n  </DiagramBoundary></>\n}\n`)

const topics = Object.fromEntries(prep.article.sections.map(section => [section.heading, prep.article.topics.filter(t => t.heading === section.heading).map(t => t.id)]))
const assignment = { article, primaryDiagramIds: ids, sections: prep.article.sections.map(section => ({ heading: section.heading, topics: prep.article.topics.filter(t => t.heading === section.heading).map(t => ({ id: t.id, label: t.topicAfterCorrectionsCandidate ?? t.topic, ...(t.coverage === 'dynamic' ? { diagramId: t.diagramId, stages: t.stageScope } : { staticReason: t.staticReason }) })) })) }
edit('website/diagrams/articles.json', source => {
  const manifest = JSON.parse(source)
  assert.ok(!manifest.articles.some(a => a.article === article))
  manifest.articles.push(assignment)
  return json(manifest) + '\n'
})
edit('website/lib/diagram-article-acceptance.mjs', source => {
  source = once(source, 'export const TRACKED_ARTICLES =', `export const ALIGNMENT_ARTICLE = '${article}'\nexport const ALIGNMENT_EVIDENCE_PATH = 'project/records/2026-09-30/alignment-article-acceptance.json'\nexport const TRACKED_ARTICLES =`)
  source = once(source, 'TRAINING_ARTICLE, PRETRAINING_ARTICLE])', 'TRAINING_ARTICLE, PRETRAINING_ARTICLE, ALIGNMENT_ARTICLE])')
  source = once(source, 'const PRETRAINING_TOPICS =', `const ALIGNMENT_TOPICS = ${json(topics)}\n\nconst PRETRAINING_TOPICS =`)
  source = once(source, 'const configs = {', `const ALIGNMENT_INPUT_FILES = [...SHARED_INPUT_FILES, 'website/components/diagrams/alignment-walkthrough.jsx',\n${ids.map(id => `  'website/components/diagrams/${id}-walkthrough.jsx', 'website/components/diagrams/${id}.css', 'website/lib/${id}-model.mjs'`).join(',\n')}\n]\nconst configs = {\n  [ALIGNMENT_ARTICLE]: { primaryDiagramIds: ${json(ids)}, topics: ALIGNMENT_TOPICS, inputFiles: ALIGNMENT_INPUT_FILES, evidencePath: ALIGNMENT_EVIDENCE_PATH, requireReadingStage: true },`)
  return once(source, 'const overrideDirectories = {', "const overrideDirectories = {\n  [ALIGNMENT_ARTICLE]: 'llm-internals',")
})
write('project/records/2026-09-30/alignment-article-acceptance.json', json({ schemaVersion: 1, article, review: null, local: null, public: null }) + '\n')
edit('website/tests/unit/diagram-article-acceptance.test.mjs', source => {
  source = once(source, '  PRETRAINING_ARTICLE, PRETRAINING_EVIDENCE_PATH, PRETRAINING_INPUT_FILES\n}', '  PRETRAINING_ARTICLE, PRETRAINING_EVIDENCE_PATH, PRETRAINING_INPUT_FILES, ALIGNMENT_ARTICLE\n}')
  source = once(source, 'TRAINING_ARTICLE, PRETRAINING_ARTICLE])', 'TRAINING_ARTICLE, PRETRAINING_ARTICLE, ALIGNMENT_ARTICLE])')
  return source + read('TEMP/alignment-acceptance-tests.txt')
})
write('website/tests/unit/alignment-decoration.test.mjs', read('TEMP/alignment-decoration.test.mjs'))
if (!dryRun) for (const [file, value] of pending) writeFileSync(path.join(root, file), value)
console.log(JSON.stringify({ dryRun, files: [...pending.keys()], article, diagrams: ids, topics: Object.values(topics).flat().length, corrections: prep.corrections.map(c => c.id), acceptance: 'pending' }))
