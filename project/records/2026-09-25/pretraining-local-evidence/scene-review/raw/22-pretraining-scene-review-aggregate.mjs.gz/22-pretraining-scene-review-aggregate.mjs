import {readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import path from 'node:path'
const tmp=process.env.TEMP, root=path.join(tmp,'pretraining-scene-audit')
const dirs={initialEdge:'local-c2-chromium-2026-09-29T16-21-51-776Z',initialWebKit:'local-c2-webkit-2026-09-29T16-21-58-473Z',finalEdge:'local-c2-chromium-2026-09-29T16-40-17-123Z',finalWebKitLossLimited:'local-c2-loss-limited-webkit-2026-09-29T16-40-15-343Z'}
const sha=b=>createHash('sha256').update(b).digest('hex'), read=async f=>JSON.parse(await readFile(f,'utf8'))
const reports={}, summary={}
for(const [key,dir] of Object.entries(dirs)){
 const file=path.join(root,dir,'result.json'),r=await read(file);reports[key]=r
 const observations=r.cases.flatMap(c=>c.pretrainingGeometryObservations??[])
 for(const c of r.cases){if(typeof c.midpointVisits==='number')c.midpointVisits={length:c.midpointVisits};if(c.readingStops)c.readingStops=Object.values(c.readingStops).flatMap(s=>s.forward)}
 summary[key]={file,sha256:sha(await readFile(file)),buildId:r.before.buildId,browser:r.browser,startedAt:r.startedAt,finishedAt:r.finishedAt,status:r.status,cases:r.cases.length,passed:r.cases.filter(c=>c.status==='passed').length,failed:r.cases.filter(c=>c.status!=='passed').map(c=>({name:c.name,error:c.error})),assets:r.assets.length,png:r.screenshots.length,localIdentityUnchanged:r.localIdentityUnchanged,inputs:r.before.inputs.length,documents:r.before.documents.length,observations:observations.length,overlapCandidates:observations.reduce((s,o)=>s+(o.overlapCandidates?.length??0),0),wireText:observations.reduce((s,o)=>s+(o.wireText?.length??0),0),profiles:r.cases.filter(c=>c.geometry).map(c=>({name:c.name,stages:Object.values(c.geometry).flat().length,minRenderedFontPx:Math.min(...Object.values(c.geometry).flat().flatMap(o=>o.fonts.map(f=>f.renderedFontPx))),maxOverflow:Math.max(...Object.values(c.geometry).flat().map(o=>o.overflow)),outside:Object.values(c.geometry).flat().reduce((s,o)=>s+o.outside.length+o.controlsOutside.length,0)})),midpointVisits:r.cases.reduce((s,c)=>s+(c.midpointVisits?.length??0),0),selectorVisits:r.cases.reduce((s,c)=>s+(c.selectorVisits?.length??0),0),uniqueControls:new Set(r.cases.flatMap(c=>c.selectorVisits??[]).map(v=>v.control)).size,uniqueOptions:new Set(r.cases.flatMap(c=>c.selectorVisits??[]).map(v=>`${v.control}:${v.value}`)).size,readingStops:r.cases.flatMap(c=>c.readingStops??[]).length,playback:r.cases.filter(c=>c.playback).map(c=>({name:c.name,playback:c.playback}))}
}
const paths=await read(path.join(tmp,'pretraining-scene-actually-viewed-paths.json')),ledgers={final:[],old:[]}
for(const [kind,list] of Object.entries(paths))for(const file of list){
 const report=Object.values(reports).find(r=>r.screenshots.some(s=>s.file.replaceAll('\\','/')===file.replaceAll('\\','/')))
 const captured=report?.screenshots.find(s=>s.file.replaceAll('\\','/')===file.replaceAll('\\','/'))
 const base=path.basename(file),profile=base.match(/\d+x\d+-(light|dark)-dsf\d/)
 ledgers[kind].push({file,sha256:sha(await readFile(file)),buildId:'RuEOJ2GbDzXcNrG4UDMh4',engine:report?.browser.engine??'chromium',channel:report?report.browser.channel:'msedge',profile:profile?.[0]??(kind==='old'?'1440x1000 light DSF1':'1440x1000 light DSF1; print/noJS/modal or selector condition in filename'),capture:base.endsWith('-scene.png')?'supplemental-full-scene':'viewport',actuallyViewed:true,verdict:'No actual glyph overlap, cropped meaning, or misleading relationship found in this inspected image',metadata:captured??null})
}
for(const [kind,ledger] of Object.entries(ledgers))await writeFile(path.join(tmp,`pretraining-scene-viewed-${kind}.json`),JSON.stringify(ledger,null,2)+'\n')
await writeFile(path.join(tmp,'pretraining-scene-review-aggregated.json'),JSON.stringify(summary,null,2)+'\n')
console.log(JSON.stringify({summaries:Object.fromEntries(Object.entries(summary).map(([k,v])=>[k,{...v,failed:v.failed.map(f=>f.name),playback:v.playback.map(p=>p.name)}])),viewed:{final:ledgers.final.length,old:ledgers.old.length}},null,2))
