# 推論S6 PUBLIC-V1 修正版の公開focused確認

所有はTEMPの inference-score-spacing-public-*。ローカルreviewと元PR61 changes_requestedは凍結したまま保持する。この準備段階では公開HTTP・browserを実行しない。

## 入力と実行順

1. rootが修正PRをmergeし、対象main CIとPages成功を確認する。
2. 同runのcollector `artifact-evidence.json` と `download/artifact.tar` を取得する。
3. rootの変更していない公開kit全91をEdge/WebKitで完了する。両方のdone `result.json` が必須で、未完結果は読まない。
4. `config.example.json` を新しいTEMPファイルへ複製し、actual merge/run/CI BUILD、collector、tar、両done resultの絶対パスを設定する。旧PR61/ローカルBUILDは拒否される。Git actual merge objectがrepoに存在する必要がある。
5. `node <TEMP>/inference-score-spacing-public-run.mjs <absolute-config.json> chromium`、同様に `webkit` を実行する。各engineの出力先は日時別ディレクトリ。初回を上書きしない。

各engine16観測（通常6profile＋modal2profile×draw/logit）、計32。フォント18/22、全6桁/負号/選択A/B、最小8SVG余白、overflow、無加工full-scene/viewport取得は凍結localと同じ関数bytesを使用する。

## 配信同一性

- actual mergeのGit blobから8記事のAST/assignment/registry/inputFiles digestを再構成し、凍結local候補8入力と一致させる。他7はPR61から不変であることを明記。
- collectorのexact CI tarをarchiveTarSHA256で検証し、8HTMLと全公開kit観測assetをtarから直接読み出しhash照合。ローカルout/BUILDを公開の期待値に使わない。
- 前後で8公開HTML/BUILDとkit観測assetをHTTP取得してCI tarと照合。browserが実際に読むdocument/script/stylesheet/font/imageもCI期待hashと照合。
- 全requestfailedへURL/type/header/time/phase/contextClosingを保存。除外可能なのはERR_ABORTEDのfetchで、CI tarにあるHTMLページ、または明示RSC/prefetchヘッダ付きのCI navigation payloadだけ。未知・図解asset・通常必須resource・console/pageerrorは失敗。context.close起因を仮定しない。

## 実画像と最終判定

機械結果は independentVisualReview=pending-actual-images のまま。実際にview_imageで見た公開画像だけを別の台帳へsourceFile/sha256/engine/profile/capture/actuallyViewed付きで保存する。最低全32図比較scene、PC/低画面/狭幅/modalの代表viewportを確認する。生成枚数を視認枚数と混同しない。

公開reviewでPUBLIC-V1がactual published fixで解消したかを明示し、新BUILD/merge/8HTML/資産・両full91を引用する。他7はsource input不変＋current full91と限定current画像確認による持ち越しであることを説明し、全旧図を再視認したと主張しない。物理端末・実スクリーンリーダーは今回も別検証。

`public-selfcheck.mjs` は旧版/ローカルBUILD拒否、設定契約、BUILD parse、凍結core同一性だけをoffline確認する。これを公開受入と扱わない。
